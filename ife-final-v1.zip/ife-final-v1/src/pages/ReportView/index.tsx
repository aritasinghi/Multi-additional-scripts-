import { useState } from 'react';
import {
    Banner,
    Button,
    Container,
    Chip,
    Table,
    TextLink,
    Pagination,
    ButtonIcon,
} from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './ReportView.css';

// ─── Types ───────────────────────────────────────────────────────────────────

interface ReportViewProps {
    reportTitle: string;
    reportDate: string;
    language: Language;
    onBack: () => void;
    onSubscribe: () => void;
    onDownload?: () => void;
}

// Report type controls which columns SHOW content — all columns always rendered
type ReportType = 'statutory' | 'full' | 'agm' | 'short';
type SortField = 'name' | 'bookEntries' | 'votes';
type SortDir = 'asc' | 'desc';

interface ShareRow {
    type: string;
    custodian?: string;
    amount: string;
    pct: string;
    votes: string;
    votePct: string;
    isTotal?: boolean;
}

interface OwnerRow {
    id: number;
    name: string;
    ssn: string;
    dob: string;
    asiakasrajoitus?: string;
    isRestricted?: boolean;
    isJoint?: boolean;
    isNominee?: boolean;
    isBank?: boolean;
    isCompany?: boolean;
    city?: string;
    address: string;
    postAddress: string;
    country: string;
    shares: ShareRow[];
    sektori: string;
    maksu: string;
    vero: string;
    situationDate?: string;
    jointOwners?: { name: string; linkable?: boolean }[];
    isJointSubRow?: boolean;
    jointParent?: string;
}

// ─── Column visibility per report type ───────────────────────────────────────
// ALL 12 columns always rendered. showX = whether to show content in that col.
// Ghost space maintained for hidden cols.

const COLS: Record<ReportType, {
    addr: boolean; city: boolean; custodian: boolean;
    pct: boolean; votes: boolean; votePct: boolean;
    date: boolean; sector: boolean; payment: boolean; tax: boolean;
}> = {
    //             addr   city   cust   pct    votes  vpct   date   sec    pay    tax
    statutory: { addr: true,  city: false, custodian: true,  pct: false, votes: false, votePct: false, date: true,  sector: false, payment: true,  tax: true  },
    full:      { addr: true,  city: false, custodian: true,  pct: true,  votes: true,  votePct: true,  date: false, sector: true,  payment: true,  tax: true  },
    agm:       { addr: false, city: true,  custodian: false, pct: false, votes: false, votePct: false, date: false, sector: false, payment: false, tax: false },
    short:     { addr: false, city: false, custodian: true,  pct: true,  votes: false, votePct: false, date: false, sector: false, payment: false, tax: false },
};

// ─── Sidebar descriptions ─────────────────────────────────────────────────────

const SIDEBAR_REPORT_TYPE: Record<ReportType, string> = {
    statutory: "Issuer's Shareholder List: Includes the information required under the Finnish Limited Liability Companies Act.",
    full:      'Full: As the name suggests, includes the complete content of the report with additional details.\nGeneral Meeting: The shareholder register available at the General Meeting.\nIssuer\'s Shareholder List: Includes the information required under the Finnish Limited Liability Companies Act.\nShort: The report includes ... Miten muotoillaan tämä? Käyttötarkoitus ja sisältö?',
    agm:       'General Meeting: The shareholder register available at the General Meeting. Includes only the information required under the Finnish Limited Liability Companies Act.',
    short:     'Short: The report includes the names of shareholders or nominee registration custodians, the number of book-entries per book-entry type, the total number of book-entries of all book-entry types combined ...',
};

// ─── Static data ─────────────────────────────────────────────────────────────

const SHARES_INFO = [
    { name: 'EUROFLEX A', isin: 'FI21049685930', abbr: 'EUROFLA' },
    { name: 'EUROFLEX B', isin: 'FI21049685931', abbr: 'EUROFLB' },
    { name: 'EUROFLEX C', isin: 'FI21049685932', abbr: 'EUROFLC' },
];

const SUMMARY_ROWS = [
    { aoLaji: 'EUROFLA', omistajien: '1 300', yhteis: '12', kaikkien: '1 006 970', osuus: '50,3 %', kokonaisAani: '2 000 000', osakas: '503 488', odotus: '5 000', hallinta: '10 000', yhteistili: '481 512', liikkeeseen: '1 000 000', bold: false },
    { aoLaji: 'EUROFLB', omistajien: '600',   yhteis: '24', kaikkien: '285 369',   osuus: '71,3 %', kokonaisAani: '400 000',   osakas: '285 369', odotus: '4 800', hallinta: '18 995', yhteistili: '90 836',  liikkeeseen: '400 000',   bold: false },
    { aoLaji: 'Yhteensä',omistajien: '1 900', yhteis: '36', kaikkien: '1 292 339', osuus: '53,8 %', kokonaisAani: '2 400 000', osakas: '788 857', odotus: '9 800', hallinta: '28 995', yhteistili: '572 348', liikkeeseen: '1 400 000', bold: true  },
];

const SHOW_DATA_OPTIONS = [
    { key: 'address',   label: 'Address information subject to non-disclosure' },
    { key: 'isin',      label: 'Identification code' },
    { key: 'expired',   label: 'Discontinued book-entry types' },
    { key: 'sector',    label: 'Sector information' },
    { key: 'custodian', label: 'Depository participant' },
];

const INITIAL_CHIPS = [
    { label: 'Directly-registered holdings', count: 2379, active: true },
    { label: 'Nominee-registered holdings',  count: 12,   active: false },
    { label: 'Companies',                    count: 1112, active: true },
    { label: 'Financial and insurance institutions', count: 23, active: false },
    { label: 'Households',                   count: 1856, active: true },
];

const OWNER_ROWS: OwnerRow[] = [
    {
        id: 1, name: 'Thomas-Peter Along-lastname', ssn: '120370-8902A', dob: '12.03.1970',
        address: 'Arvo-osuuskuja 212', postAddress: '00550 Espoo', country: 'Espoo, Finland',
        city: 'Espoo', situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '30 300', pct: '3,03000', votes: '60 900', votePct: '2,54000' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '600',    pct: '0,15000', votes: '',       votePct: '' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '30 900', pct: '2,21000', votes: '60 900', votePct: '2,54000', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 2, name: 'Clarck Confidential', ssn: '020377-02908', dob: '02.03.1977',
        isRestricted: true,
        address: 'Yhteyssoite: Jokitie 22 b', postAddress: '00100 Helsinki', country: 'Tai Ei osoitetta',
        city: '', situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '15', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX A', custodian: 'Nordea', amount: '15', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'OP',     amount: '40', pct: '0,00004', votes: '100', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '70', pct: '0,00003', votes: '100', votePct: '0,00003', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 3, name: 'D-Yritys OY Ab', ssn: 'T769765-S', dob: '', asiakasrajoitus: 'konkurssi',
        isCompany: true, city: 'Helsinki',
        address: 'Arvopaperie 12', postAddress: '00100 Helsinki', country: 'Helsinki, Finland',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '30', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '100', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '70', pct: '0,00003', votes: '100', votePct: '0,00003', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 4, name: 'Thomas Elling', ssn: '200274-89020', dob: '20.02.1974',
        isJoint: true, asiakasrajoitus: 'kuolinpesä', city: 'Helsinki',
        address: 'Thomaksentie 12', postAddress: '00100 Helsinki', country: 'Helsinki / Finland',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '50', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '60', pct: '0,00004', votes: '160', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '110', pct: '0,00003', votes: '160', votePct: '0,00003', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 5, name: 'Thomas Elling', ssn: '200274-89020', dob: '20.02.1974',
        isJoint: true, asiakasrajoitus: 'kuolinpesä', city: 'Helsinki',
        address: 'Thomaksentie 12', postAddress: '00100 Helsinki', country: 'Helsinki / Finland',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '30', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '603', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '70', pct: '0,00003', votes: '603', votePct: '0,00003', isTotal: true },
        ],
        jointOwners: [{ name: 'Tiina Ollila' }, { name: 'Veijo Välisää', linkable: true }],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 6, name: 'William Elling', ssn: '180372-89020', dob: '18.03.1972',
        city: 'Helsinki', address: 'Viljaminkuja 22 b 33', postAddress: '00100 Helsinki', country: 'Helsinki, Finland',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '30', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '603', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '70', pct: '0,00003', votes: '603', votePct: '0,00003', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 7, name: 'Elli Ollinen', ssn: '120378-1902B', dob: '12.03.1978',
        isJointSubRow: true, jointParent: 'Thomas Elling',
        city: 'Helsinki', address: 'Elisenkuja 6 B', postAddress: '00100 Helsinki', country: 'Helsinki/Finland',
        shares: [], sektori: '', maksu: '', vero: '',
    },
    {
        id: 8, name: 'Sakari Penttinen', ssn: '220368-3456A', dob: '23.03.1968',
        city: 'Helsinki', address: 'Sakarianpolku 1 C', postAddress: '00100 Helsinki', country: 'Helsinki, Finland',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP', amount: '30', pct: '0,00005', votes: '3', votePct: '0,00005' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '30', pct: '0,00005', votes: '3', votePct: '0,00005', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 9, name: 'SEC Custody Bank', ssn: '1169765-6', dob: '',
        isBank: true, isNominee: true, city: 'Helsinki',
        address: 'Pankkiirinkatu 32', postAddress: '00100 Helsinki', country: 'Helsinki / Finland',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '120', pct: '0,00010', votes: '70', votePct: '0,00010' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '60',  pct: '0,00010', votes: '',   votePct: '' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '180', pct: '0,00008', votes: '70', votePct: '0,00010', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
];

// ─── Ghost cell helper ────────────────────────────────────────────────────────
// Returns empty cell that preserves column space
function GhostCell() {
    return <Table.BodyCell><span className="rv__ghost"> </span></Table.BodyCell>;
}

// ─── Owner table row ─────────────────────────────────────────────────────────

function OwnerTableRow({ row, cols }: { row: OwnerRow; cols: typeof COLS[ReportType] }) {
    if (row.isJointSubRow) {
        return (
            <Table.Row className="rv__row--joint-sub">
                {/* Name col */}
                <Table.BodyCell>
                    <div className="rv__name-cell">
                        <div className="rv__name-row">
                            <span className="rv__flag">🔗</span>
                            <span className="rv__sub-label">Mukana yhteisomistuksessa</span>
                        </div>
                        <div className="rv__joint-parent">Oikeudenhaltija: <TextLink href="#">{row.jointParent}</TextLink></div>
                        <span className="rv__ssn-text">{row.ssn}</span>
                        {row.dob && <span className="rv__ssn-text">{row.dob}</span>}
                    </div>
                </Table.BodyCell>
                {/* Address — ghost if not shown */}
                {cols.addr ? (
                    <Table.BodyCell>
                        <span className="rv__cell-sm">{row.address}<br />{row.postAddress}<br />{row.country}</span>
                    </Table.BodyCell>
                ) : <GhostCell />}
                {/* City */}
                {cols.city ? <Table.BodyCell><span className="rv__cell-sm">{row.city}</span></Table.BodyCell> : <GhostCell />}
                {/* Share type */}
                <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>
                {/* Custodian */}
                {cols.custodian ? <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell> : <GhostCell />}
                {/* Amount */}
                <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>
                {/* Pct */}
                {cols.pct ? <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell> : <GhostCell />}
                {/* Votes */}
                {cols.votes ? <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell> : <GhostCell />}
                {/* VotePct */}
                {cols.votePct ? <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell> : <GhostCell />}
                {/* Date */}
                {cols.date ? <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell> : <GhostCell />}
                {/* Sector */}
                {cols.sector ? <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell> : <GhostCell />}
                {/* Payment */}
                {cols.payment ? <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell> : <GhostCell />}
                {/* Tax */}
                {cols.tax ? <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell> : <GhostCell />}
            </Table.Row>
        );
    }

    return (
        <Table.Row>
            {/* ── Name ── */}
            <Table.BodyCell>
                <div className="rv__name-cell">
                    <div className="rv__name-row">
                        {row.isBank && <span className="rv__flag" title="Nominee Registration Custodian">🏦</span>}
                        {row.isCompany && !row.isBank && <span className="rv__flag" title="Company">🏢</span>}
                        <TextLink href="#"><strong>{row.name}</strong></TextLink>
                        {row.isRestricted && <span className="rv__flag" title="Non-disclosure">🚫</span>}
                        {row.isNominee && !row.isBank && <span className="rv__flag" title="Nominee-registered">📋</span>}
                    </div>
                    <span className="rv__ssn-text">{row.ssn}</span>
                    {row.dob && <span className="rv__ssn-text">{row.dob}</span>}
                    {row.asiakasrajoitus && <span className="rv__restriction">Customer restriction: {row.asiakasrajoitus}</span>}
                    {row.isJoint && row.jointOwners && (
                        <div className="rv__joint-section">
                            <span className="rv__flag">🔗</span>
                            <span className="rv__joint-label">Yhteisomistus:</span>
                            {row.jointOwners.map((o, i) => (
                                <span key={i} className="rv__cell-sm">
                                    {o.linkable ? <TextLink href="#">{o.name}</TextLink> : o.name}
                                    {i < (row.jointOwners?.length ?? 0) - 1 && ', '}
                                </span>
                            ))}
                            <button type="button" className="rv__joint-toggle">Vai avattava? ›</button>
                        </div>
                    )}
                </div>
            </Table.BodyCell>

            {/* ── Address — ghost if not in this report type ── */}
            {cols.addr ? (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.address}<br />{row.postAddress}<br />{row.country}</span>
                </Table.BodyCell>
            ) : <GhostCell />}

            {/* ── City (AGM only) — ghost otherwise ── */}
            {cols.city ? (
                <Table.BodyCell><span className="rv__cell-sm">{row.city}</span></Table.BodyCell>
            ) : <GhostCell />}

            {/* ── Share type — always visible, vertical list ── */}
            <Table.BodyCell>
                <div className="rv__shares-vertical">
                    {row.shares.map((s, i) => (
                        <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>{s.type}</div>
                    ))}
                </div>
            </Table.BodyCell>

            {/* ── Custodian — ghost if not shown ── */}
            {cols.custodian ? (
                <Table.BodyCell>
                    <div className="rv__shares-vertical">
                        {row.shares.map((s, i) => (
                            <div key={i} className="rv__cell-sm">{s.isTotal ? '' : (s.custodian || '')}</div>
                        ))}
                    </div>
                </Table.BodyCell>
            ) : <GhostCell />}

            {/* ── Amount — always visible ── */}
            <Table.BodyCell align="middle-right">
                <div className="rv__shares-vertical">
                    {row.shares.map((s, i) => (
                        <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>{s.amount}</div>
                    ))}
                </div>
            </Table.BodyCell>

            {/* ── Pct — ghost if not shown ── */}
            {cols.pct ? (
                <Table.BodyCell align="middle-right">
                    <div className="rv__shares-vertical">
                        {row.shares.map((s, i) => (
                            <div key={i} className="rv__cell-sm">{s.pct}</div>
                        ))}
                    </div>
                </Table.BodyCell>
            ) : <GhostCell />}

            {/* ── Votes — ghost if not shown ── */}
            {cols.votes ? (
                <Table.BodyCell align="middle-right">
                    <div className="rv__shares-vertical">
                        {row.shares.map((s, i) => (
                            <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>{s.votes || ''}</div>
                        ))}
                    </div>
                </Table.BodyCell>
            ) : <GhostCell />}

            {/* ── Vote % — ghost if not shown ── */}
            {cols.votePct ? (
                <Table.BodyCell align="middle-right">
                    <div className="rv__shares-vertical">
                        {row.shares.map((s, i) => (
                            <div key={i} className="rv__cell-sm">{s.votePct || ''}</div>
                        ))}
                    </div>
                </Table.BodyCell>
            ) : <GhostCell />}

            {/* ── Situation date — ghost if not shown ── */}
            {cols.date ? (
                <Table.BodyCell><span className="rv__cell-sm">{row.situationDate}</span></Table.BodyCell>
            ) : <GhostCell />}

            {/* ── Sector — ghost if not shown ── */}
            {cols.sector ? (
                <Table.BodyCell><span className="rv__cell-sm">{row.sektori}</span></Table.BodyCell>
            ) : <GhostCell />}

            {/* ── Payment — ghost if not shown ── */}
            {cols.payment ? (
                <Table.BodyCell><span className="rv__cell-sm">{row.maksu}</span></Table.BodyCell>
            ) : <GhostCell />}

            {/* ── Tax — ghost if not shown ── */}
            {cols.tax ? (
                <Table.BodyCell><span className="rv__cell-sm">{row.vero}</span></Table.BodyCell>
            ) : <GhostCell />}
        </Table.Row>
    );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function ReportView({ reportTitle, reportDate, language, onBack, onSubscribe, onDownload }: ReportViewProps) {
    const t = translations[language].reportView;

    // State
    const [activeTab, setActiveTab] = useState<'report' | 'subscription'>('report');
    // Default = statutory (Issuer's shareholder list) per spec
    const [reportType, setReportType] = useState<ReportType>('statutory');
    const [showData, setShowData] = useState<Record<string, boolean>>(
        Object.fromEntries(SHOW_DATA_OPTIONS.map(o => [o.key, true]))
    );
    const [chips, setChips] = useState(INITIAL_CHIPS);
    const [search, setSearch] = useState('');
    const [sortField, setSortField] = useState<SortField>('name');
    const [sortDir, setSortDir] = useState<SortDir>('asc');
    const [currentPage, setCurrentPage] = useState(1);
    const totalPages = 14;

    const cols = COLS[reportType];
    const toggleChip = (label: string) =>
        setChips(prev => prev.map(c => c.label === label ? { ...c, active: !c.active } : c));

    // Report type options — Issuer's shareholder list first (default per spec)
    const reportTypeOptions: { key: ReportType; title: string; desc: string }[] = [
        { key: 'statutory', title: "Issuer's shareholder list", desc: 'Statutory information' },
        { key: 'full',      title: 'Full',                      desc: 'All available information' },
        { key: 'agm',       title: 'General meeting',           desc: 'Shareholder register for the general meeting' },
        { key: 'short',     title: 'Short',                     desc: 'Names of shareholders and number of shares' },
    ];

    const filteredRows = OWNER_ROWS.filter(row =>
        !search || row.name.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <>
            {/* ── Banner with efi Banner.Tabs + Actions ── */}
            <Banner appName="MyEuroclear" sticky={true}>
                <Banner.Title>{reportDate} {reportTitle}</Banner.Title>
                <Banner.Actions>
                    <button type="button" className="rv__download-btn" onClick={onDownload}>
                        {/* ico_download */}
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                            <path d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                            <path d="M7 11l5 5 5-5M12 4v12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        {t.downloadFile}
                        {/* ico_sm_dropdown */}
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                            <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                    </button>
                </Banner.Actions>
                <Banner.Tabs
                    value={activeTab}
                    onValueChange={(val: string) => setActiveTab(val as 'report' | 'subscription')}
                >
                    <Banner.Tab value="report">{t.tabReport}</Banner.Tab>
                    <Banner.Tab value="subscription">{t.tabSubscriptionInfo}</Banner.Tab>
                </Banner.Tabs>
            </Banner>

            <Container>
                <div className="rv">

                    {activeTab === 'report' && (
                        <>
                            {/* ══ SUMMARY CARD ══ */}
                            <section className="rv__summary-card">
                                <h2 className="rv__section-title">{t.summaryTitle}</h2>
                                <div className="rv__info-row">
                                    <div className="rv__info-block">
                                        <h4 className="rv__info-heading">{t.infoTitle}</h4>
                                        <p className="rv__info-line">{t.issuer}: <strong>Euroflex Oyj</strong></p>
                                        <p className="rv__info-line">{t.reportName}: <strong>Liikkeeseenlaskijan omistusraportti</strong></p>
                                        <p className="rv__info-line">{t.situationDate}: <strong>13.3.2026</strong></p>
                                    </div>
                                    <div className="rv__shares-block">
                                        <h4 className="rv__info-heading">Arvo-osuudet</h4>
                                        <div className="rv__shares-grid">
                                            {SHARES_INFO.map(s => (
                                                <div key={s.isin} className="rv__share-col">
                                                    <p className="rv__info-line">{t.shareNameLabel}: <strong>{s.name}</strong></p>
                                                    <p className="rv__info-line">{t.isinLabel}: <strong>{s.isin}</strong></p>
                                                    <p className="rv__info-line">{t.abbreviationLabel}: <strong>{s.abbr}</strong></p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                <h3 className="rv__sub-title">Yhteenveto</h3>
                                <div className="rv__summary-table-wrap">
                                    <Table layout="fixed" hover striped>
                                        <Table.Head>
                                            <Table.Row>
                                                <Table.HeadCell column="ao" sortable>BOOK-ENTRY TYPE</Table.HeadCell>
                                                <Table.HeadCell column="om">NUMBER OF OWNERS AND NOMINEE-REGISTRATION CUSTODIANS</Table.HeadCell>
                                                <Table.HeadCell column="yh">NUMBER OF JOINT OWNERS</Table.HeadCell>
                                                <Table.HeadCell column="kk">NUMBER OF VOTES CONFERRED BY ALL THE BOOK-ENTRIES IN BOOK-ENTRY ACCOUNTS</Table.HeadCell>
                                                <Table.HeadCell column="os">PERCENTAGE OF VOTES CONFERRED BY ALL THE BOOK-ENTRIES</Table.HeadCell>
                                                <Table.HeadCell column="ka">TOTAL NUMBER OF VOTES</Table.HeadCell>
                                                <Table.HeadCell column="ol">IN THE SHAREHOLDER LIST</Table.HeadCell>
                                                <Table.HeadCell column="od">IN THE WAITING LIST</Table.HeadCell>
                                                <Table.HeadCell column="hr">NOMINEE-REGISTERED</Table.HeadCell>
                                                <Table.HeadCell column="yt">IN THE JOINT ACCOUNT</Table.HeadCell>
                                                <Table.HeadCell column="lm">ISSUED AMOUNT</Table.HeadCell>
                                            </Table.Row>
                                        </Table.Head>
                                        <Table.Body>
                                            {SUMMARY_ROWS.map(row => (
                                                <Table.Row key={row.aoLaji}>
                                                    <Table.BodyCell>{row.bold ? <strong>{row.aoLaji}</strong> : row.aoLaji}</Table.BodyCell>
                                                    <Table.BodyCell>{row.omistajien}</Table.BodyCell>
                                                    <Table.BodyCell>{row.yhteis}</Table.BodyCell>
                                                    <Table.BodyCell>{row.kaikkien}</Table.BodyCell>
                                                    <Table.BodyCell>{row.osuus}</Table.BodyCell>
                                                    <Table.BodyCell>{row.kokonaisAani}</Table.BodyCell>
                                                    <Table.BodyCell>{row.osakas}</Table.BodyCell>
                                                    <Table.BodyCell>{row.odotus}</Table.BodyCell>
                                                    <Table.BodyCell>{row.hallinta}</Table.BodyCell>
                                                    <Table.BodyCell>{row.yhteistili}</Table.BodyCell>
                                                    <Table.BodyCell>{row.liikkeeseen}</Table.BodyCell>
                                                </Table.Row>
                                            ))}
                                        </Table.Body>
                                    </Table>
                                </div>
                            </section>

                            {/* ══ FILTERS + SIDEBAR — 80/20 ══ */}
                            <div className="rv__content-layout">

                                {/* LEFT 80% */}
                                <div className="rv__filters-left">

                                    {/* Report type */}
                                    <section className="rv__filter-section">
                                        <h3 className="rv__filter-label">
                                            {t.reportTypeTitle}
                                            <ButtonIcon className="rv__info-btn" aria-label="Report type info">
                                                <ButtonIcon.Icon icon="info" />
                                            </ButtonIcon>
                                        </h3>
                                        <div className="rv__radio-row">
                                            {reportTypeOptions.map(({ key, title, desc }) => (
                                                <label key={key} className="rv__radio-option">
                                                    <input
                                                        type="radio"
                                                        name="reportType"
                                                        checked={reportType === key}
                                                        onChange={() => setReportType(key)}
                                                        className="rv__radio-input"
                                                    />
                                                    <span className="rv__radio-content">
                                                        <span className="rv__radio-title">{title}</span>
                                                        <span className="rv__radio-desc">{desc}</span>
                                                    </span>
                                                </label>
                                            ))}
                                        </div>
                                    </section>

                                    {/* Show data */}
                                    <section className="rv__filter-section">
                                        <h3 className="rv__filter-label">
                                            {t.showDataTitle}
                                            <ButtonIcon className="rv__info-btn" aria-label="Show data info">
                                                <ButtonIcon.Icon icon="info" />
                                            </ButtonIcon>
                                        </h3>
                                        <div className="rv__checkbox-row">
                                            {SHOW_DATA_OPTIONS.map(opt => (
                                                <label key={opt.key} className="rv__checkbox-option">
                                                    <input
                                                        type="checkbox"
                                                        checked={showData[opt.key]}
                                                        onChange={() => setShowData(p => ({ ...p, [opt.key]: !p[opt.key] }))}
                                                        className="rv__checkbox-input"
                                                    />
                                                    <span className="rv__checkbox-label">{opt.label}</span>
                                                </label>
                                            ))}
                                        </div>
                                    </section>

                                    {/* Filtering */}
                                    <section className="rv__filter-section rv__filter-section--last">
                                        <h3 className="rv__filter-label">
                                            {t.filterTitle}
                                            <ButtonIcon className="rv__info-btn" aria-label="Filtering info">
                                                <ButtonIcon.Icon icon="info" />
                                            </ButtonIcon>
                                        </h3>
                                        <div className="rv__chips-row">
                                            {chips.map(chip => (
                                                <Chip
                                                    key={chip.label}
                                                    mode="selectable"
                                                    size="medium"
                                                    selected={chip.active}
                                                    onClick={() => toggleChip(chip.label)}
                                                >
                                                    {chip.label}
                                                    <Chip.Counter>{chip.count}</Chip.Counter>
                                                </Chip>
                                            ))}
                                        </div>
                                    </section>
                                </div>

                                {/* RIGHT 20% — sidebar */}
                                <div className="rv__sidebar">
                                    <section className="rv__sidebar-section">
                                        <h4 className="rv__sidebar-title">{t.reportTypeTitle}</h4>
                                        <p className="rv__sidebar-text" style={{ whiteSpace: 'pre-line' }}>{SIDEBAR_REPORT_TYPE[reportType]}</p>
                                    </section>
                                    <section className="rv__sidebar-section">
                                        <h4 className="rv__sidebar-title">{t.showDataTitle}</h4>
                                        <p className="rv__sidebar-text">In the Show details section, you can control which columns are displayed in the table.</p>
                                    </section>
                                    <section className="rv__sidebar-section">
                                        <h4 className="rv__sidebar-title">{t.filterTitle}</h4>
                                        <p className="rv__sidebar-text">Filters allow you to control the content shown in the table. Clearing an option filters the table so that those holdings are excluded.</p>
                                    </section>
                                    <section className="rv__sidebar-section rv__sidebar-section--last">
                                        <h4 className="rv__sidebar-title">{t.fileDownloadTitle}</h4>
                                        <p className="rv__sidebar-text">In the file download window, you can choose which report type and file format to download.</p>
                                    </section>
                                </div>
                            </div>

                            {/* ══ SEARCH + LEGEND — one line ══ */}
                            <div className="rv__search-and-legend">
                                <p className="rv__filter-summary">
                                    {t.filteredSummary || 'With filtered:'} owners 224 kpl, holdings 2391 kpl
                                </p>
                                <div className="rv__search-box">
                                    <input
                                        type="text"
                                        placeholder={t.searchPlaceholder || 'Search owner by name'}
                                        value={search}
                                        onChange={e => setSearch(e.target.value)}
                                        onKeyDown={e => e.key === 'Enter' && console.log('Search:', search)}
                                        className="rv__search-input"
                                    />
                                    <span className="rv__search-icon">🔍</span>
                                </div>
                                <div className="rv__legend-row">
                                    <span className="rv__legend-item">🚫 Non-disclosure</span>
                                    <span className="rv__legend-item">🔗 Joint ownership</span>
                                    <span className="rv__legend-item">📋 Nominee-registered holding</span>
                                    <span className="rv__legend-item">🏦 Nominee Registration Custodians</span>
                                </div>
                            </div>

                            {/* ══ OWNER TABLE — fixed layout, ghost columns ══ */}
                            <div className="rv__table-wrap">
                                <Table layout="fixed" hover>
                                    <Table.Head>
                                        <Table.Row>
                                            {/* Col 1 — Name, always teal sort col */}
                                            <Table.HeadCell column="name" sortable className="rv__col--sort rv__th" style={{ width: '13%' }}>
                                                NAME
                                                <Table.SecondaryText>IDENTIFICATION CODE</Table.SecondaryText>
                                                <Table.SecondaryText>DATE OF BIRTH</Table.SecondaryText>
                                                <Table.SecondaryText>CUSTOMER RESTRICTIONS</Table.SecondaryText>
                                            </Table.HeadCell>
                                            {/* Col 2 — Address, ghost header if not shown */}
                                            <Table.HeadCell column="addr" className={`rv__th ${!cols.addr ? 'rv__th--ghost' : ''}`} style={{ width: '11%' }}>
                                                {cols.addr ? <>STREET ADDRESS<Table.SecondaryText>POST ADDRESS</Table.SecondaryText><Table.SecondaryText>MUNICIPALITY, COUNTRY</Table.SecondaryText></> : ''}
                                            </Table.HeadCell>
                                            {/* Col 3 — City (AGM) / ghost */}
                                            <Table.HeadCell column="city" className={`rv__th ${!cols.city ? 'rv__th--ghost' : ''}`} style={{ width: '7%' }}>
                                                {cols.city ? 'MUNICIPALITY' : ''}
                                            </Table.HeadCell>
                                            {/* Col 4 — Share type, always shown */}
                                            <Table.HeadCell column="type" className="rv__th" style={{ width: '12%' }}>
                                                NAME OF THE BOOK-ENTRY TYPE
                                            </Table.HeadCell>
                                            {/* Col 5 — Custodian, ghost if not shown */}
                                            <Table.HeadCell column="cust" className={`rv__th ${!cols.custodian ? 'rv__th--ghost' : ''}`} style={{ width: '8%' }}>
                                                {cols.custodian ? 'DEPOSITORY PARTICIPANT' : ''}
                                            </Table.HeadCell>
                                            {/* Col 6 — Amount, always shown */}
                                            <Table.HeadCell column="amt" align="right" className="rv__th" style={{ width: '7%' }}>
                                                NUMBER OF BOOK-ENTRIES
                                            </Table.HeadCell>
                                            {/* Col 7 — Pct, ghost if not shown */}
                                            <Table.HeadCell column="pct" align="right" className={`rv__th ${!cols.pct ? 'rv__th--ghost' : ''}`} style={{ width: '8%' }}>
                                                {cols.pct ? 'PERCENTAGE OF BOOK-ENTRIES COMBINED' : ''}
                                            </Table.HeadCell>
                                            {/* Col 8 — Votes */}
                                            <Table.HeadCell column="votes" align="right" className={`rv__th ${!cols.votes ? 'rv__th--ghost' : ''}`} style={{ width: '7%' }}>
                                                {cols.votes ? 'NUMBER OF VOTES' : ''}
                                            </Table.HeadCell>
                                            {/* Col 9 — Vote pct */}
                                            <Table.HeadCell column="vpct" align="right" className={`rv__th ${!cols.votePct ? 'rv__th--ghost' : ''}`} style={{ width: '8%' }}>
                                                {cols.votePct ? 'PERCENTAGE OF TOTAL VOTING RIGHTS' : ''}
                                            </Table.HeadCell>
                                            {/* Col 10 — Date */}
                                            <Table.HeadCell column="date" sortable className={`rv__th ${!cols.date ? 'rv__th--ghost' : ''}`} style={{ width: '7%' }}>
                                                {cols.date ? 'SITUATION DATE' : ''}
                                            </Table.HeadCell>
                                            {/* Col 11 — Sector */}
                                            <Table.HeadCell column="sec" className={`rv__th ${!cols.sector ? 'rv__th--ghost' : ''}`} style={{ width: '8%' }}>
                                                {cols.sector ? 'SECTOR' : ''}
                                            </Table.HeadCell>
                                            {/* Col 12 — Payment */}
                                            <Table.HeadCell column="pay" className={`rv__th ${!cols.payment ? 'rv__th--ghost' : ''}`} style={{ width: '7%' }}>
                                                {cols.payment ? 'PAYMENT INFORMATION' : ''}
                                            </Table.HeadCell>
                                            {/* Col 13 — Tax */}
                                            <Table.HeadCell column="tax" className={`rv__th ${!cols.tax ? 'rv__th--ghost' : ''}`} style={{ width: '6%' }}>
                                                {cols.tax ? 'TAX INFORMATION' : ''}
                                            </Table.HeadCell>
                                        </Table.Row>
                                    </Table.Head>
                                    <Table.Body>
                                        {filteredRows.map(row => (
                                            <OwnerTableRow key={row.id} row={row} cols={cols} />
                                        ))}
                                    </Table.Body>
                                </Table>
                            </div>

                            {/* ══ PAGINATION ══ */}
                            <div className="rv__pagination">
                                <Pagination.Root
                                    as="button"
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    maxPages={5}
                                    onPageChange={(page: number) => setCurrentPage(page)}
                                    showFirst
                                    showLast
                                    showNext
                                    showPrevious
                                    ariaLabels={{
                                        first: 'Move to first page',
                                        last: 'Move to last page',
                                        nav: 'Navigate between paginated table',
                                        next: 'Move to next page',
                                        page: 'Move to page',
                                        previous: 'Move to previous page',
                                    }}
                                />
                            </div>
                        </>
                    )}

                    {activeTab === 'subscription' && (
                        <div className="rv__subscription-tab">
                            <p>Subscription info — coming soon</p>
                        </div>
                    )}
                </div>
            </Container>
        </>
    );
}
