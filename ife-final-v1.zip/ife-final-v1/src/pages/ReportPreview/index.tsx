import { Banner, Button, Container, Table } from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './ReportPreview.css';

interface ReportPreviewProps {
    reportTitle: string;
    language: Language;
    onBack: () => void;
    onSubscribe: () => void;
}

const REPORT_ROWS = [
    'Osakkeiden määrä',
    'Osakkeiden yhteismäärä, osuus osakkeiden kokonaismäärästä',
    'Henkilö- ja yksilöintitunnus',
    'Maksu- ja verotustiedot, tilinhoitajatieto',
    'Osoitetiedot, maatieto, turvakielliset',
    'Äänimäärätiedot',
    'Sektoritieto',
    'Asiakasrajoitus',
];

const MATRIX: Record<string, boolean[]> = {
    'Osakkeiden määrä':         [true, true, true, true],
    'Osakkeiden yhteismäärä, osuus osakkeiden kokonaismäärästä': [true, true, true, true],
    'Henkilö- ja yksilöintitunnus': [true, true, true, true],
    'Maksu- ja verotustiedot, tilinhoitajatieto': [true, true, true, false],
    'Osoitetiedot, maatieto, turvakielliset': [true, true, true, true],
    'Äänimäärätiedot':          [true, false, false, false],
    'Sektoritieto':             [true, false, false, false],
    'Asiakasrajoitus':          [true, false, false, false],
};

const CheckIcon = () => (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
        <rect x="1" y="1" width="18" height="18" rx="3" fill="#00B9A4" />
        <path d="M6 10l3 3 5-6" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export default function ReportPreview({ reportTitle, language, onBack, onSubscribe }: ReportPreviewProps) {
    const t = translations[language].reportPreview;
    const cols = [t.full, t.agm, t.statutory, t.short];

    return (
        <>
            <Banner appName="MyEuroclear">
                <Banner.Title>
                    <span className="rp__bc">{t.breadcrumbRoot} {'>'} {t.breadcrumbReports}</span>
                </Banner.Title>
                <Banner.Subtitle>{t.title} {reportTitle}</Banner.Subtitle>
            </Banner>

            <Container>
                {/* Content + action buttons */}
                <div className="rp__top-row">
                    <div className="rp__top-left">
                        <h2 className="rp__h2">{t.orderableDataTitle}: {reportTitle}</h2>
                        <h3 className="rp__h3">{t.whatIsThisTitle}</h3>
                        <p className="rp__desc">{t.whatIsThisDesc}</p>
                    </div>
                    <div className="rp__top-actions">
                        <Button variant="secondary" semantic="normal" size="medium" onClick={onBack}>{t.back}</Button>
                        <Button variant="primary" semantic="normal" size="medium" onClick={onSubscribe}>{t.toSubscription}</Button>
                    </div>
                </div>

                {/* Matrix table using efi Table */}
                <h3 className="rp__matrix-title">{t.reportTypesTitle}</h3>
                <div className="rp__table-wrap">
                    <Table layout="auto"
                           defaultSort="desc">
                        <Table.Head>
                            <Table.Row>
                                <Table.HeadCell column="dataType"> </Table.HeadCell>
                                {cols.map((col) => (
                                    <Table.HeadCell key={col} column={col}>{col}</Table.HeadCell>
                                ))}
                            </Table.Row>
                        </Table.Head>
                        <Table.Body>
                            {REPORT_ROWS.map((row) => (
                                <Table.Row key={row}>
                                    <Table.BodyCell>{row}</Table.BodyCell>
                                    {MATRIX[row].map((checked, i) => (
                                        <Table.BodyCell key={i} align="middle-right">
                                            {checked ? <CheckIcon /> : null}
                                        </Table.BodyCell>
                                    ))}
                                </Table.Row>
                            ))}
                        </Table.Body>
                    </Table>
                </div>

                {/* Example image */}
                <h3 className="rp__h3" style={{ marginTop: '2rem' }}>{t.exampleTitle}</h3>
                <div className="rp__example-img">
                    <img
                        src="/images/report-example.png"
                        alt="Report example"
                        className="rp__example-screenshot"
                        onError={(e) => {
                            (e.target as HTMLImageElement).style.display = 'none';
                            (e.target as HTMLImageElement).parentElement!.classList.add('rp__example-fallback');
                        }}
                    />
                </div>
            </Container>
        </>
    );
}
