import {Checkbox, CheckboxGroup, Container, Fieldset, Table, Status, DoneIcon} from '@efi/efi-ui-components';
import Field from "@/components/Field";
import type { Language } from '@/locales';
import { translationsOrgPage } from '@/locales';


import './OrganisationPage.css';

interface OrganisationPageProps {
    language: Language
}

export default function OrganisationPage({ language }: OrganisationPageProps) {
    const t = translationsOrgPage[language];


    const organisationInfo = {
        name: "Euroflex Prime",
        businessId: "123456-1",
        lei: "529900CX3J4RP09HKG12",
        street: "Urho Kekkosen katu 5",
        city: "Helsinki",
        type: "Liikkeeseenlaskija",
        postalCode: "00100",
        country: "Suomi",
        issuerType: "Osakeliikkeeseenlaskija",
        joinedSystem: "2.5.2005",
        leftSystem: "-",
    };

    const shareClasses = [
        {
            name: "Euroflex A",
            short: "EUFLA",
            isin: "FI21049685930",
            type: "Osake",
            votes: "1:10",
            clause: "Sulkulauseke",
            status: "Aktiivinen",
        },
        {
            name: "Euroflex B",
            short: "EUFLB",
            isin: "FI21049685931",
            type: "Osake",
            votes: "1:1",
            clause: "Ei",
            status: "Päättynyt",
        }
    ];

    const contractInfo = {
        activeContract: "Information Elements by Euroclear",
        startDate: "1.11.2026",
        endDate: "-",
        status: "Aktiivinen"
    };

    const fields = [
        { heading: t.name, value: organisationInfo.name },
        { heading: t.businessId, value: organisationInfo.businessId },
        { heading: t.lei, value: organisationInfo.lei },
        { heading: t.street, value: organisationInfo.street },
        { heading: t.city, value: organisationInfo.city },
    ];

    return (
        <>
            <Container>
                <div>
                    <div className="header-row">
                        <Container.Heading>{t.generalInfo}</Container.Heading>
                        <Container.Heading>{t.address}</Container.Heading>
                    </div>

                    <div className="HorizontalLine" />
                    <div className="VerticalLineWrapper">
                        <div className="VerticalLine" />
                    </div>

                    <div><br /></div>

                    <Fieldset orientation="horizontal" allowWrap>
                        <div className="field-gap">
                            {fields.slice(0, 3).map(f => (
                                <Field key={f.heading} heading={f.heading} value={f.value} />
                            ))}

                            {fields.slice(3).map(f => (
                                <Field key={f.heading} heading={f.heading} value={f.value} />
                            ))}
                        </div>
                    </Fieldset>

                    <div><br /></div>

                    <Fieldset orientation="horizontal" allowWrap>
                        <div className="Row">
                            <Field heading={t.orgType} value={organisationInfo.type} />

                            <div className="CheckboxGroupRoot">
                                <CheckboxGroup
                                    name="language"
                                    onValueChange={(values) => console.log(values)}
                                >
                                    <CheckboxGroup.Legend>{t.emailLanguage}</CheckboxGroup.Legend>

                                    <div className="lang">
                                        <Checkbox name="language" value="Suomi">
                                            <Checkbox.Label>{t.finnish}</Checkbox.Label>
                                        </Checkbox>
                                    </div>

                                    <Checkbox name="language" value="Englanti">
                                        <Checkbox.Label>{t.english}</Checkbox.Label>
                                    </Checkbox>
                                </CheckboxGroup>
                            </div>

                            <div className="LastFields">
                                <Field heading={t.postalCode} value={organisationInfo.postalCode} />
                                <Field heading={t.country} value={organisationInfo.country} />
                            </div>
                        </div>
                    </Fieldset>

                    <div><br /></div>

                    <Fieldset orientation="horizontal" allowWrap>
                        <Field heading={t.issuerType} value={organisationInfo.issuerType} />
                    </Fieldset>

                    <div><br /></div>

                    <Fieldset orientation="horizontal" allowWrap>
                        <Field heading={t.joinedSystem} value={organisationInfo.joinedSystem} />

                        <div className="pad-left">
                            <Field heading={t.leftSystem} value={organisationInfo.leftSystem} />
                        </div>
                    </Fieldset>

                    <div><br /></div>

                    <div className="HorizontalLine" />

                    <div><br /></div>

                    <div className="TableHeading">{t.shareClasses}</div>

                    <div><br /></div>

                    <Table layout="auto"
                           defaultSort="desc" >
                        <Table.Head>
                            <Table.Row>
                                <Table.HeadCell column="nimi" sortable sortDirection="desc">{t.name}</Table.HeadCell>
                                <Table.HeadCell column="lyhenne">{t.short}</Table.HeadCell>
                                <Table.HeadCell column="ISIN">{t.isin}</Table.HeadCell>
                                <Table.HeadCell column="laji">{t.type}</Table.HeadCell>
                                <Table.HeadCell column="Ääniä">{t.votes}</Table.HeadCell>
                                <Table.HeadCell column="Suostumus">{t.clause}</Table.HeadCell>
                                <Table.HeadCell column="Status">{t.status}</Table.HeadCell>
                            </Table.Row>
                        </Table.Head>

                        <Table.Body>
                            <>
                                {shareClasses.map((s, i) => (
                                    <Table.Row key={i}>
                                        <Table.BodyCell>{s.name}</Table.BodyCell>
                                        <Table.BodyCell>{s.short}</Table.BodyCell>
                                        <Table.BodyCell>{s.isin}</Table.BodyCell>
                                        <Table.BodyCell>{s.type}</Table.BodyCell>
                                        <Table.BodyCell>{s.votes}</Table.BodyCell>
                                        <Table.BodyCell>{s.clause}</Table.BodyCell>
                                        <Table.BodyCell>{s.status}</Table.BodyCell>
                                    </Table.Row>
                                ))}
                            </>
                        </Table.Body>
                    </Table>
                </div>
            </Container>

            <div style={{ height: "2rem" }} />

            <Container>
                <Container.Heading>{t.contractInfo}</Container.Heading>

                <div><br /></div>

                <Fieldset orientation="horizontal" allowWrap>
                    <div className="nowrap">
                        <Field heading={t.activeContract} value={contractInfo.activeContract} />

                        <div className="status">


                            <DoneIcon></DoneIcon>
                            <Status semantic="primary" size="medium" variant="round">
                                {contractInfo.status}
                            </Status>
                        </div>
                    </div>

                    <div className="left-align">
                        <Field heading={t.contractStart} value={contractInfo.startDate} />
                    </div>

                    <Field heading={t.contractEnd} value={contractInfo.endDate} />
                </Fieldset>
            </Container>
        </>
    );
}