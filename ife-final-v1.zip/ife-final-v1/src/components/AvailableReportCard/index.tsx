import { Card, Button } from '@efi/efi-ui-components';
import './AvailableReportCard.css';

interface AvailableReportCardProps {
    title: string;
    description?: string;
    previewLabel: string;
    subscribeLabel: string;
    onPreview?: () => void;
    onSubscribe?: () => void;
}

export function AvailableReportCard({ title, description, previewLabel, subscribeLabel, onPreview, onSubscribe }: AvailableReportCardProps) {
    return (
        <Card>
            <Card.Heading>
                <span className="ois-avail__heading-wrap">
                    {title}
                    <span className="ois-avail__plus">+</span>
                </span>
            </Card.Heading>

            {description && (
                <p className="ois-avail__desc">{description}</p>
            )}

            <Card.Footer>
                <Button variant="secondary" semantic="normal" size="medium" onClick={onPreview}>
                    {previewLabel}
                </Button>
                <Button variant="primary" semantic="normal" size="medium" onClick={onSubscribe}>
                    {subscribeLabel}
                </Button>
            </Card.Footer>
        </Card>
    );
}
