import { Card, Button } from '@efi/efi-ui-components';
import './Card.css';

interface DataRow { name: string; percentage: number }

interface SubscribedCardProps {
    title: string;
    badge?: string;
    data: DataRow[];
    lastReportDate: string;
    subscribedCount: number;
    showLatestLabel: string;
    showAllLabel: string;
    subscribeLabel: string;
    onShowLatest?: () => void;
    onShowAll?: () => void;
    onSubscribe?: () => void;
}

export function SubscribedCard({ title, badge, data, lastReportDate, subscribedCount, showLatestLabel, showAllLabel, subscribeLabel, onShowLatest, onShowAll, onSubscribe }: SubscribedCardProps) {
    const formatPct = (val: number) => val.toFixed(2).replace('.', ',') + ' %';

    return (
        <Card>
            <Card.Heading>
                <span className="ois-card__heading-wrap">
                    {title}
                    {badge && <span className="ois-card__badge">{badge}</span>}
                </span>
            </Card.Heading>

            {/* Data rows */}
            <div className="ois-card__data">
                {data.map((row) => (
                    <div key={row.name} className="ois-card__row">
                        <span className="ois-card__name">{row.name.toUpperCase()}</span>
                        <span className="ois-card__pct">{formatPct(row.percentage)}</span>
                    </div>
                ))}
            </div>

            {/* Centered link */}
            <a className="ois-card__link" href="#" onClick={(e) => { e.preventDefault(); onShowLatest?.(); }}>
                {showLatestLabel}: {lastReportDate}
            </a>

            <Card.Footer>
                <Button variant="secondary" semantic="normal" size="medium" onClick={onShowAll}>
                    {showAllLabel} ({subscribedCount})
                </Button>
                <Button variant="primary" semantic="normal" size="medium" onClick={onSubscribe}>
                    + {subscribeLabel}
                </Button>
            </Card.Footer>
        </Card>
    );
}
