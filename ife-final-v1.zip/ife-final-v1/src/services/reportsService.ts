import apiClient from '@/api/client';

export interface ReportTypeDTO {
    report_type_id: number;
    report_name: string;
    report_group: number;
}

export interface CreateReportOrderRequest {
    reportTypeId: number;
    organizationId: number;
    userId: string;
    reportDate: string;
    instruments: number[];
    referenceCode?: string;
}

export interface CreateOrderResponse {
    reportOrderId: number;
}

export const REPORT_TYPE_LABELS: Record<string, Record<string, string>> = {
    'SHAREHOLDER_LIST':       { fi: 'Liikkeeseenlaskijan osakasluettelo', en: 'Issuer shareholder list', sv: 'Emittentens aktieägarförteckning' },
    'SHAREHOLDER_PUBLIC':     { fi: 'Julkinen osakasluettelo', en: 'Public shareholder list', sv: 'Offentlig aktieägarförteckning' },
    'SHAREHOLDER_CUSTOM':     { fi: 'Osakaspoiminta', en: 'Custom shareholder extraction', sv: 'Anpassat aktieägaruttag' },
    'SHAREHOLDER_BIGGEST':    { fi: 'Suurimmat omistajat', en: 'Largest shareholders', sv: 'Största aktieägarna' },
    'SECTOR_DISTRIBUTION':    { fi: 'Sektorijakauma', en: 'Sector distribution', sv: 'Sektorsfördelning' },
    'OWNERSHIP_DISTRIBUTION': { fi: 'Omistusmääräjakauma', en: 'Ownership distribution', sv: 'Äganderättsfördelning' },
    'TEMPORARY_SHAREHOLDER_LIST': { fi: 'Tilapäinen osakasluettelo', en: 'Temporary shareholder list', sv: 'Tillfällig aktieägarförteckning' },
    'SEQUENCE':               { fi: 'Sektorijakauma', en: 'Sector distribution', sv: 'Sektorsfördelning' },
};

export const REPORT_TYPE_DESCRIPTIONS: Record<string, string> = {
    'SHAREHOLDER_LIST':       'Raportti on luettelo liikkeeseenlaskijan puolesta ABESO:n mukaisesti Euroclear Finlandin ylläpitämään arvo-osuusjärjestelmään liitetystä tai siihen sisältyvistä osakkeiden omistajista.',
    'SHAREHOLDER_PUBLIC':     'Raportti sisältää julkiset osakasluettelotiedot.',
    'SHAREHOLDER_CUSTOM':     'Raportissa kuvataan valittujen omistajien tiedot.',
    'SHAREHOLDER_BIGGEST':    'Raportti perustuu osakasluetteloon, mutta sisältää vain arvo-osuuksien suurimmat omistajat. Suurten omistajien lukumäärä on valittavissa tilauksen yhteydessä.',
    'SECTOR_DISTRIBUTION':    'Raportti perustuu Tilastokeskuksen sektoriluokitukseen ja kuvaa omistajien ja hallintarekisteröityjen säilyttäjien sektorijakaumaa.',
    'OWNERSHIP_DISTRIBUTION': 'Raportissa kuvataan omistusten jakauma osakkeenomistajien omistusten perusteella. Jos kaikki osakelajit valitaan, näytetään yhdistetyt tiedot.',
    'TEMPORARY_SHAREHOLDER_LIST': 'Raportti sisältää liikkeeseenlaskijan osakasluetteloon merkityt suoraan rekisteröidyt omistajat yhtiökokouksen täsmäytyspäivältä sekä kaikki hallintarekisteröityjen osakkeenomistajien merkinnät.',
    'SEQUENCE':               'Raportti perustuu Tilastokeskuksen sektoriluokitukseen ja kuvaa omistajien ja hallintarekisteröityjen säilyttäjien sektorijakaumaa.',
};

export const reportsApi = {
    getReportTypes: async (): Promise<ReportTypeDTO[]> => {
        const { data } = await apiClient.get<ReportTypeDTO[]>('/reports/reporttypes');
        return data;
    },
    createOrder: async (request: CreateReportOrderRequest): Promise<CreateOrderResponse> => {
        const { data } = await apiClient.post<CreateOrderResponse>('/reports/order/', request);
        return data;
    },
};
