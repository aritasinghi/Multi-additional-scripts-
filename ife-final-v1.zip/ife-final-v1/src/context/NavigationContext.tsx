import { createContext, useContext, useState, useCallback, useMemo } from 'react';
import type { ReactNode } from 'react';

export type View =
    | { type: 'landing' }
    | { type: 'preview'; reportId: string; reportTitle: string }
    | { type: 'subscribedList'; reportId: string; reportTitle: string }
    | { type: 'reportView'; reportId: string; reportTitle: string; reportDate: string };

interface NavigationContextValue {
    currentView: View;
    navigateTo: (view: View) => void;
    goBack: () => void;
    goHome: () => void;
}

const NavigationContext = createContext<NavigationContextValue | undefined>(undefined);

export function useNavigation() {
    const ctx = useContext(NavigationContext);
    if (!ctx) throw new Error('useNavigation must be used within <NavigationProvider>');
    return ctx;
}

export function NavigationProvider({ children }: { children: ReactNode }) {
    const [currentView, setCurrentView] = useState<View>({ type: 'landing' });
    const [_, setHistory] = useState<View[]>([]);

    const navigateTo = useCallback((view: View) => {
        setHistory((prev) => [...prev, currentView]);
        setCurrentView(view);
    }, [currentView]);

    const goBack = useCallback(() => {
        setHistory((prev) => {
            const next = [...prev];
            const last = next.pop();
            if (last) setCurrentView(last);
            else setCurrentView({ type: 'landing' });
            return next;
        });
    }, []);

    const goHome = useCallback(() => {
        setCurrentView({ type: 'landing' });
        setHistory([]);
    }, []);

    const value = useMemo(() => ({ currentView, navigateTo, goBack, goHome }), [currentView, navigateTo, goBack, goHome]);

    return <NavigationContext.Provider value={value}>{children}</NavigationContext.Provider>;
}
