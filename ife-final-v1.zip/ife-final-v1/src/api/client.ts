import axios from 'axios';
import Env from '@/config/Env';

const raw = (typeof Env !== "undefined" && Env.API_SERVER_URL) ? Env.API_SERVER_URL : "";

let baseURL = raw;

// Ensure /api is present
if (!baseURL.includes("/api")) {
    baseURL = baseURL.replace(/\/$/, "") + "/api";
}

console.log("Final baseURL =", baseURL);


const apiClient = axios.create({
    baseURL,
    timeout: 30000,
    headers: {

        "Content-Type": "application/json",
        Accept: "application/json",
    },

});

export default apiClient;
