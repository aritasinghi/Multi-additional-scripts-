import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
    plugins: [react()],
    base: '',
    resolve: {
        alias: {
            '@': path.resolve(__dirname, 'src'),
            '@efi-css': path.resolve(__dirname, 'node_modules/@efi/efi-ui-components/dist')
        }
    }
})
