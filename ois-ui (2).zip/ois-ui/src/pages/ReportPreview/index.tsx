import type { Language } from '@/locales';
import { translations } from '@/locales';
import './ReportPreview.css';

interface ReportPreviewProps {
    reportTitle: string;
    language: Language;
    onBack: () => void;
    onSubscribe: () => void;
}

const REPORT_ROWS = [
    'Osakkeiden määrä',
    'Osakkeiden yhteismäärä, osuus osakkeiden kokonaismäärästä',
    'Henkilö- ja yksilöintitunnus',
    'Maksu- ja verotustiedot, tilinhoitajatieto',
    'Osoitetiedot, maatieto, turvakielliset',
    'Äänimäärätiedot',
    'Sektoritieto',
    'Asiakasrajoitus',
];

const REPORT_MATRIX: Record<string, boolean[]> = {
    'Osakkeiden määrä': [true, true, true, true],
    'Osakkeiden yhteismäärä, osuus osakkeiden kokonaismäärästä': [true, true, true, true],
    'Henkilö- ja yksilöintitunnus': [true, true, false, false],
    'Maksu- ja verotustiedot, tilinhoitajatieto': [true, true, false, false],
    'Osoitetiedot, maatieto, turvakielliset': [true, true, false, false],
    'Äänimäärätiedot': [true, false, false, false],
    'Sektoritieto': [true, false, false, false],
    'Asiakasrajoitus': [true, false, false, false],
};

export default function ReportPreview({ reportTitle, language, onBack, onSubscribe }: ReportPreviewProps) {
    const t = translations[language].reportPreview;
    const columns = [t.full, t.agm, t.statutory, t.short];

    return (
        <div className="report-preview">
            {/* Breadcrumb */}
            <nav className="report-preview__breadcrumb">
                <span>{t.breadcrumbRoot}</span>
                <span className="report-preview__breadcrumb-sep">{'>'}</span>
                <span className="report-preview__breadcrumb-active">{t.breadcrumbReports}</span>
            </nav>

            <h1 className="report-preview__title">{t.title} <span className="report-preview__title-report">{reportTitle}</span></h1>

            {/* Orderable data section */}
            <section className="report-preview__section">
                <h2 className="report-preview__section-title">{t.orderableDataTitle}: {reportTitle}</h2>

                <h3 className="report-preview__subtitle">{t.whatIsThisTitle}</h3>
                <p className="report-preview__desc">{t.whatIsThisDesc}</p>
            </section>

            {/* Report types matrix table */}
            <section className="report-preview__section">
                <h3 className="report-preview__subtitle">{t.reportTypesTitle}</h3>

                <div className="report-preview__matrix">
                    <table className="report-preview__table">
                        <thead>
                            <tr>
                                <th />
                                {columns.map((col) => (
                                    <th key={col} className="report-preview__col-header">{col}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {REPORT_ROWS.map((row) => (
                                <tr key={row}>
                                    <td className="report-preview__row-label">{row}</td>
                                    {REPORT_MATRIX[row].map((checked, i) => (
                                        <td key={i} className="report-preview__check-cell">
                                            {checked && <span className="report-preview__check">✓</span>}
                                        </td>
                                    ))}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </section>

            {/* Example section */}
            <section className="report-preview__section">
                <h3 className="report-preview__subtitle">{t.exampleTitle}</h3>
                <div className="report-preview__example-placeholder">
                    {/* TODO: Add example report screenshot/preview */}
                </div>
            </section>

            {/* Actions */}
            <div className="report-preview__actions">
                <button className="report-preview__btn report-preview__btn--outlined" type="button" onClick={onBack}>{t.back}</button>
                <button className="report-preview__btn report-preview__btn--primary" type="button" onClick={onSubscribe}>{t.toSubscription}</button>
            </div>
        </div>
    );
}
