import { Card } from '@/components/Card';
import { AvailableReportCard } from '@/components/AvailableReportCard';
import { translations } from '@/locales';
import type { Language } from '@/locales';
import './ReportsPage.css';

interface ReportsPageProps {
    language: Language;
    onSubscribe?: (reportId: string, reportTitle?: string) => void;
    onShowPreview?: (reportId: string, reportTitle: string) => void;
    onShowAllSubscribed?: (reportId: string, reportTitle: string, count: number) => void;
    onShowLatest?: (reportId: string, reportTitle: string) => void;
}

const SUBSCRIBED_REPORTS = [
    {
        id: '1', title: 'Liikkeeseenlaskijan osakasluettelo', badge: 'UUSI',
        data: [{ name: 'Tulip Bank', percentage: 10.00 }, { name: 'Flexis Bank', percentage: 9.00 }, { name: 'S. Sunflower', percentage: 8.00 }, { name: 'C. Coriander', percentage: 7.00 }, { name: 'H. Hazel', percentage: 6.00 }, { name: 'T. Tulip', percentage: 5.00 }],
        lastReportDate: '24.01.2026', subscribedCount: 3,
    },
    {
        id: '2', title: 'Julkinen osakasluettelo',
        data: [{ name: 'Tulip Bank', percentage: 10.00 }, { name: 'Flexis Bank', percentage: 9.00 }, { name: 'S. Sunflower', percentage: 8.00 }, { name: 'C. Coriander', percentage: 7.00 }, { name: 'H. Hazel', percentage: 6.00 }, { name: 'T. Tulip', percentage: 5.00 }],
        lastReportDate: '01.01.2026', subscribedCount: 1,
    },
    {
        id: '3', title: 'Kattava omistajapoiminta',
        data: [{ name: 'Tulip Bank', percentage: 10.00 }, { name: 'Flexis Bank', percentage: 9.00 }, { name: 'S. Sunflower', percentage: 8.00 }, { name: 'C. Coriander', percentage: 7.00 }, { name: 'H. Hazel', percentage: 6.00 }, { name: 'T. Tulip', percentage: 5.00 }],
        lastReportDate: '24.11.2025', subscribedCount: 4,
    },
];

const AVAILABLE_REPORTS = [
    { id: '4', title: 'Suurimmat omistajat', description: 'Raportti perustuu osakasluetteloon, mutta sisältää vain arvo-osuuksien suurimmat omistajat. Suurten omistajien lukumäärä on valittavissa tilauksen yhteydessä.' },
    { id: '5', title: 'Sektorijakauma', description: 'Raportti perustuu Tilastokeskuksen sektoriluokitukseen ja kuvaa omistajien ja hallintarekisteröityjen säilyttäjien sektorijakaumaa.' },
    { id: '6', title: 'Omistusmääräjakauma', description: 'Raportissa kuvataan omistusten jakauma osakkeenomistajien omistusten perusteella. Jos kaikki osakelajit valitaan, näytetään yhdistetyt tiedot. Jos raportti tilataan vain yhdelle osakelajille, raportti esitetään kyseisen osakelajin mukaan.' },
    { id: '7', title: 'Omistajapoiminta', description: 'Raportissa...' },
    { id: '8', title: 'Tilapäinen osakasluettelo', description: 'Raportti sisältää liikkeeseenlaskijan osakasluetteloon merkityt suoraan rekisteröidyt omistajat yhtiökokouksen täsmäytyspäivältä sekä kaikki hallintarekisteröityjen osakkeenomistajien merkinnät.' },
];

export default function ReportsPage({ language, onSubscribe, onShowPreview, onShowAllSubscribed, onShowLatest }: ReportsPageProps) {
    const t = translations[language].reports;

    return (
        <div className="reports-page">
            {/* Subscribed report types */}
            <section className="reports-page__section">
                <h3 className="reports-page__section-title">{t.subscribedTitle}</h3>
                <div className="reports-page__grid">
                    {SUBSCRIBED_REPORTS.map((report) => (
                        <Card
                            key={report.id}
                            title={report.title}
                            badge={report.badge}
                            data={report.data}
                            lastReportDate={report.lastReportDate}
                            subscribedCount={report.subscribedCount}
                            showLatestLabel={t.showLatestReport}
                            showAllLabel={t.showAllSubscribed}
                            subscribeLabel={t.subscribeNew}
                            onShowLatest={() => onShowLatest?.(report.id, report.title)}
                            onShowAll={() => onShowAllSubscribed?.(report.id, report.title, report.subscribedCount)}
                            onSubscribe={() => onSubscribe?.(report.id, report.title)}
                        />
                    ))}
                </div>
            </section>

            {/* Available report types */}
            <section className="reports-page__section">
                <h3 className="reports-page__section-title">{t.availableTitle}</h3>
                <div className="reports-page__grid">
                    {AVAILABLE_REPORTS.map((report) => (
                        <AvailableReportCard
                            key={report.id}
                            title={report.title}
                            previewLabel={t.showPreview}
                            subscribeLabel={t.subscribe}
                            onPreview={() => onShowPreview?.(report.id, report.title)}
                            onSubscribe={() => onSubscribe?.(report.id, report.title)}
                        />
                    ))}
                </div>
            </section>
        </div>
    );
}
