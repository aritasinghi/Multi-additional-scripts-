import { useState } from 'react';
import { translations } from '@/locales';
import type { Language } from '@/locales';
import { ProfileMenu } from '@/components/ProfileMenu';
import { SubscriptionModal } from '@/components/SubscriptionModal';
import { DownloadModal } from '@/components/DownloadModal';
import type { SubscriptionFormData } from '@/components/SubscriptionModal';
import type { DownloadOptions } from '@/components/DownloadModal';
import ReportsPage from './ReportsPage';
import ReportPreview from './ReportPreview';
import ReportView from './ReportView';
import SubscribedReports from './SubscribedReports';
import './LandingPage.css';

// ---------------------------------------------------------------------------
// Navigation state — which page/view is active
// ---------------------------------------------------------------------------
type View =
    | { type: 'landing' }
    | { type: 'preview'; reportId: string; reportTitle: string }
    | { type: 'subscribedList'; reportId: string; reportTitle: string }
    | { type: 'reportView'; reportId: string; reportTitle: string; reportDate: string };

export default function LandingPage() {
    const [language, setLanguage] = useState<Language>("en");
    const [activeTab, setActiveTab] = useState<string>("reports");
    const [currentView, setCurrentView] = useState<View>({ type: 'landing' });

    // Modal states
    const [subscriptionModal, setSubscriptionModal] = useState<{ open: boolean; reportTitle: string }>({ open: false, reportTitle: '' });
    const [downloadModal, setDownloadModal] = useState(false);

    const t = translations[language];

    const tabs = [
        { label: t.tabs.reports, path: "reports" },
        { label: t.tabs.log, path: "log" },
        { label: t.tabs.organization, path: "organization" },
    ];

    // ── Navigation handlers ──
    const navigateTo = (view: View) => setCurrentView(view);
    const goBackToLanding = () => setCurrentView({ type: 'landing' });

    const handleShowPreview = (reportId: string, reportTitle: string) => {
        navigateTo({ type: 'preview', reportId, reportTitle });
    };

    const handleShowAllSubscribed = (reportId: string, reportTitle: string, subscribedCount: number) => {
        if (subscribedCount === 1) {
            // Single report → open directly
            navigateTo({ type: 'reportView', reportId, reportTitle, reportDate: '01.11.2025' });
        } else {
            // Multiple → show list
            navigateTo({ type: 'subscribedList', reportId, reportTitle });
        }
    };

    const handleOpenReport = (reportId: string) => {
        const view = currentView;
        if (view.type === 'subscribedList') {
            navigateTo({ type: 'reportView', reportId, reportTitle: view.reportTitle, reportDate: '01.11.2025' });
        }
    };

    const handleShowLatest = (reportId: string, reportTitle: string) => {
        navigateTo({ type: 'reportView', reportId, reportTitle, reportDate: '01.11.2025' });
    };

    const handleSubscribe = (_reportId: string, reportTitle?: string) => {
        setSubscriptionModal({ open: true, reportTitle: reportTitle ?? '' });
    };

    const handleSubscriptionSubmit = (data: SubscriptionFormData) => {
        console.log('Subscription submitted:', data);
        setSubscriptionModal({ open: false, reportTitle: '' });
    };

    const handleDownload = (options: DownloadOptions) => {
        console.log('Download requested:', options);
        setDownloadModal(false);
        // TODO: Trigger actual file download via API
    };

    // ── Tab content renderer ──
    const renderTabContent = () => {
        switch (activeTab) {
            case 'reports':
                return (
                    <ReportsPage
                        language={language}
                        onSubscribe={handleSubscribe}
                        onShowPreview={handleShowPreview}
                        onShowAllSubscribed={handleShowAllSubscribed}
                        onShowLatest={handleShowLatest}
                    />
                );
            case 'log':
                return <p>{t.content.log}</p>;
            case 'organization':
                return <p>{t.content.organization}</p>;
            default:
                return null;
        }
    };

    // ── Main content based on current view ──
    const renderMainContent = () => {
        switch (currentView.type) {
            case 'preview':
                return (
                    <ReportPreview
                        reportTitle={currentView.reportTitle}
                        language={language}
                        onBack={goBackToLanding}
                        onSubscribe={() => handleSubscribe(currentView.reportId, currentView.reportTitle)}
                    />
                );

            case 'subscribedList':
                return (
                    <SubscribedReports
                        reportTitle={currentView.reportTitle}
                        language={language}
                        onReportClick={handleOpenReport}
                    />
                );

            case 'reportView':
                return (
                    <ReportView
                        reportTitle={currentView.reportTitle}
                        reportDate={currentView.reportDate}
                        language={language}
                        onBack={() => {
                            // Go back to subscribed list or landing
                            goBackToLanding();
                        }}
                        onSubscribe={() => handleSubscribe(currentView.reportId, currentView.reportTitle)}
                        onDownload={() => setDownloadModal(true)}
                    />
                );

            case 'landing':
            default:
                return (
                    <>
                        <div className="ois-banner">
                            <span className="ois-banner__app-name">MyEuroclear</span>
                            <h1 className="ois-banner__title">{t.tabs[activeTab as keyof typeof t.tabs]}</h1>
                        </div>
                        <div className="ois-container">
                            <h2 className="ois-container__heading">{t.welcome}</h2>
                            {renderTabContent()}
                        </div>
                    </>
                );
        }
    };

    return (
        <>
            {/* ── Header ── */}
            <header className="ois-header">
                <div className="ois-header__top">
                    <button className="ois-header__hamburger" type="button" aria-label={t.header.openMenu}>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                            <path d="M3 5h14M3 10h14M3 15h14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                        </svg>
                    </button>
                    <span className="ois-header__app-name">{t.header.appName}</span>
                    <div className="ois-header__right">
                        <span className="ois-header__org">{t.header.orgLabel}</span>
                        <ProfileMenu
                            userName="Justin Time"
                            company="Wishing Well Investments"
                            department="Marketing and communications"
                            language={language}
                            onLanguageChange={setLanguage}
                            onNavigate={(path) => console.log('Navigate to:', path)}
                            onLogout={() => console.log('Logout')}
                        />
                    </div>
                </div>
                <nav className="ois-header__nav">
                    {tabs.map(({ label, path }) => (
                        <button
                            key={path}
                            className={`ois-header__nav-item ${activeTab === path ? 'ois-header__nav-item--active' : ''}`}
                            onClick={() => { setActiveTab(path); goBackToLanding(); }}
                            type="button"
                        >
                            {label}
                        </button>
                    ))}
                </nav>
            </header>

            {/* ── Main content ── */}
            <main className="ois-main">
                {renderMainContent()}
            </main>

            {/* ── Modals ── */}
            <SubscriptionModal
                isOpen={subscriptionModal.open}
                reportTitle={subscriptionModal.reportTitle}
                onClose={() => setSubscriptionModal({ open: false, reportTitle: '' })}
                onSubmit={handleSubscriptionSubmit}
                language={language}
            />

            <DownloadModal
                isOpen={downloadModal}
                language={language}
                onClose={() => setDownloadModal(false)}
                onDownload={handleDownload}
            />
        </>
    );
}
