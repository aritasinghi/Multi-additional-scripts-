import type { Language } from '@/locales';
import { translations } from '@/locales';
import './SubscribedReports.css';

interface SubscribedReport {
    id: string;
    date: string;
    orderedAt: string;
    frequency: string;
    reference: string;
    status: 'ready' | 'processing';
}

interface SubscribedReportsProps {
    reportTitle: string;
    language: Language;
    onReportClick: (reportId: string) => void;
}

const MOCK_REPORTS: SubscribedReport[] = [
    { id: '1', date: '11.12.2025', orderedAt: '11.12.2025, 09:00', frequency: 'oneTime', reference: '1234567890', status: 'processing' },
    { id: '2', date: '1.11.2025', orderedAt: '01.01.2024, 08:20', frequency: 'monthly', reference: '-', status: 'ready' },
    { id: '3', date: '1.10.2025', orderedAt: '01.01.2024, 08:20', frequency: 'monthly', reference: '-', status: 'ready' },
];

export default function SubscribedReports({ reportTitle, language, onReportClick }: SubscribedReportsProps) {
    const t = translations[language].subscribedReports;

    const getFrequencyLabel = (freq: string) => freq === 'oneTime' ? t.oneTime : t.monthly;

    return (
        <div className="sub-reports">
            <h1 className="sub-reports__title">{reportTitle}</h1>
            <div className="sub-reports__card">
                <h2 className="sub-reports__card-title">{t.title}</h2>
                <p className="sub-reports__note">{t.availabilityNote}</p>

                <table className="sub-reports__table">
                    <thead>
                        <tr>
                            <th>{t.colDate}</th>
                            <th>{t.colOrdered}</th>
                            <th>{t.colFrequency}</th>
                            <th>{t.colReference}</th>
                            <th>{t.colStatus}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {MOCK_REPORTS.map((report) => (
                            <tr key={report.id}>
                                <td>
                                    <button className="sub-reports__date-link" type="button" onClick={() => onReportClick(report.id)}>
                                        {report.date}
                                    </button>
                                </td>
                                <td>{report.orderedAt}</td>
                                <td>{getFrequencyLabel(report.frequency)}</td>
                                <td>{report.reference}</td>
                                <td>
                                    <span className={`sub-reports__status sub-reports__status--${report.status}`}>
                                        {report.status === 'ready' ? '✓' : '⏳'} {report.status === 'ready' ? t.statusReady : t.statusProcessing}
                                    </span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
