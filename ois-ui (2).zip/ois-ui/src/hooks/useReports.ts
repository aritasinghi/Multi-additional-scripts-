import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { queryKeys } from '@/api/queryKeys';
import { reportsService } from '@/api/services/reportsService';
import type { SubscriptionFormValues } from '@/types';

export const useSubscribedReports = () => {
    return useQuery({
        queryKey: queryKeys.reports.subscribed(),
        queryFn: reportsService.getSubscribed,
    });
};

export const useAvailableReports = () => {
    return useQuery({
        queryKey: queryKeys.reports.available(),
        queryFn: reportsService.getAvailable,
    });
};

export const useReportDetail = (id: string) => {
    return useQuery({
        queryKey: queryKeys.reports.detail(id),
        queryFn: () => reportsService.getById(id),
        enabled: !!id,
    });
};

export const useSubscribeToReport = () => {
    const qc = useQueryClient();
    return useMutation({
        mutationFn: (values: SubscriptionFormValues) => reportsService.subscribe(values),
        onSuccess: () => {
            qc.invalidateQueries({ queryKey: queryKeys.reports.subscribed() });
            qc.invalidateQueries({ queryKey: queryKeys.reports.available() });
        },
    });
};

export const useUnsubscribeFromReport = () => {
    const qc = useQueryClient();
    return useMutation({
        mutationFn: (id: string) => reportsService.unsubscribe(id),
        onSuccess: () => {
            qc.invalidateQueries({ queryKey: queryKeys.reports.subscribed() });
            qc.invalidateQueries({ queryKey: queryKeys.reports.available() });
        },
    });
};
