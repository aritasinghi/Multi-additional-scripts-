/**
 * Application-wide constants.
 */
export const APP_NAME = 'Information Elements by Euroclear';
export const ORG_LABEL = 'Organisaatio: Euroflex';
export const DEFAULT_LANGUAGE = 'en';

export const TAB_KEYS = {
    REPORTS: 'reports',
    EVENT_LOG: 'log',
    ORGANISATION: 'organization',
} as const;
