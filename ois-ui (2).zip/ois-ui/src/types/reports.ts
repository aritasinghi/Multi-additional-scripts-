/** A single row in the report data preview table */
export interface ReportDataRow {
    name: string;
    percentage: number;
}

/** A subscribed report card */
export interface SubscribedReport {
    id: string;
    title: string;
    data: ReportDataRow[];
    lastReportDate: string;
    subscribedCount: number;
    badge?: string;
}

/** An available (unsubscribed) report type */
export interface AvailableReport {
    id: string;
    title: string;
    hasPreview?: boolean;
}

/** Subscription form values — "Tilaa raportti" modal */
export interface SubscriptionFormValues {
    reportId: string;
    dateMode: 'latest' | 'custom';
    customDate?: string;
    frequency: 'once' | 'daily' | 'monthly' | 'quarterly' | 'yearly';
    monthDay?: number;
    valueShares: string[];
    reference?: string;
}
