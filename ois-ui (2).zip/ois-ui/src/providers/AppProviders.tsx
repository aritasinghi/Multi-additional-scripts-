import type { ReactNode } from 'react';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from '@/api/queryClient';

// When efi library is available, swap this import:
//   FROM: import { ThemeProvider } from '@/components/ThemeProvider';
//   TO:   import { ThemeProvider } from '@efi/efi-ui-components';
import { ThemeProvider } from '@/components/ThemeProvider';
import type { Theme } from '@/components/ThemeProvider';

// TODO: Add when auth is ready
// import { AuthProvider } from '@/features/auth/AuthProvider';
// import { UserProvider } from '@/features/auth/UserProvider';

interface AppProvidersProps {
    theme?: Theme;
    children: ReactNode;
}

/**
 * AppProviders — wraps the entire app with all required providers.
 *
 * Order matters:
 * 1. QueryClientProvider  — data fetching (outermost, no UI dependency)
 * 2. ThemeProvider         — CSS variables, theme context
 * 3. AuthProvider          — (future) OpenAM/OIDC session
 * 4. UserProvider          — (future) user profile context
 */
export function AppProviders({ theme = 'light', children }: AppProvidersProps) {
    return (
        <QueryClientProvider client={queryClient}>
            <ThemeProvider theme={theme}>
                {/* TODO: Wrap with auth when ready */}
                {/* <AuthProvider {...oidcConfig}> */}
                {/*     <UserProvider> */}
                            {children}
                {/*     </UserProvider> */}
                {/* </AuthProvider> */}
            </ThemeProvider>
        </QueryClientProvider>
    );
}
