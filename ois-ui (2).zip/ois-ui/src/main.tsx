/**
 * Application entry point.
 *
 * Structure:
 *   main.tsx          — bootstraps React, imports global CSS
 *   providers/        — AppProviders wraps all context providers
 *   pages/LandingPage — root page component
 *
 * CSS load order (when efi library is available):
 *   1. @efi-css/css/variables.css
 *   2. @efi-css/css/base.css
 *   3. @efi-css/css/fonts.css
 *   4. @efi-css/css/theme-light.css
 *   5. @efi-css/css/index.css
 */

import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';

// ── Global styles ──────────────────────────────────────────────────────────
// TODO: Replace with efi-css imports once @efi/efi-ui-components is installed
// import '@efi-css/css/variables.css';
// import '@efi-css/css/base.css';
// import '@efi-css/css/fonts.css';
// import '@efi-css/css/theme-light.css';
// import '@efi-css/css/index.css';
import './index.css';

// ── App ────────────────────────────────────────────────────────────────────
import { AppProviders } from '@/providers';
import LandingPage from '@/pages/LandingPage';

// ── Mount ──────────────────────────────────────────────────────────────────
const root = document.getElementById('root');

if (!root) {
    throw new Error('Root element #root not found in document.');
}

createRoot(root).render(
    <StrictMode>
        <AppProviders theme="light">
            <LandingPage />
        </AppProviders>
    </StrictMode>,
);
