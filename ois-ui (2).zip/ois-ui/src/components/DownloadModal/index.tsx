import { useState } from 'react';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './DownloadModal.css';

type ReportType = 'short' | 'full' | 'agm' | 'statutory';
type FileType = 'csv' | 'xls' | 'pdf';

interface DownloadModalProps {
    isOpen: boolean;
    language: Language;
    onClose: () => void;
    onDownload: (options: DownloadOptions) => void;
}

export interface DownloadOptions {
    reportType: ReportType;
    useFilteredVersion: boolean;
    fileType: FileType;
    downloadLanguage: 'fi' | 'en';
}

export function DownloadModal({ isOpen, language, onClose, onDownload }: DownloadModalProps) {
    const t = translations[language].downloadModal;
    const rt = translations[language].reportView;

    const [reportType, setReportType] = useState<ReportType>('full');
    const [useFiltered, setUseFiltered] = useState(true);
    const [fileType, setFileType] = useState<FileType>('csv');
    const [dlLang, setDlLang] = useState<'fi' | 'en'>('fi');

    if (!isOpen) return null;

    const reportTypes: { key: ReportType; label: string; desc: string }[] = [
        { key: 'short', label: translations[language].reportPreview.short, desc: rt.shortDesc },
        { key: 'full', label: translations[language].reportPreview.full, desc: rt.fullDesc },
        { key: 'agm', label: translations[language].reportPreview.agm, desc: rt.agmDesc },
        { key: 'statutory', label: translations[language].reportPreview.statutory, desc: rt.statutoryDesc },
    ];

    const handleDownload = () => {
        onDownload({ reportType, useFilteredVersion: useFiltered, fileType, downloadLanguage: dlLang });
    };

    return (
        <div className="dl-modal__overlay" onClick={onClose}>
            <div className="dl-modal" onClick={(e) => e.stopPropagation()}>
                <h2 className="dl-modal__title">{t.title}</h2>

                <div className="dl-modal__divider" />

                {/* Report type */}
                <section className="dl-modal__section">
                    <h3 className="dl-modal__label">{t.reportTypeTitle}</h3>
                    <div className="dl-modal__radios">
                        {reportTypes.map(({ key, label, desc }) => (
                            <label key={key} className="dl-modal__radio">
                                <input type="radio" name="dlReportType" checked={reportType === key} onChange={() => setReportType(key)} />
                                <span className="dl-modal__radio-dot" />
                                <span>
                                    <strong>{label}</strong><br />
                                    <span className="dl-modal__radio-desc">{desc}</span>
                                </span>
                            </label>
                        ))}
                    </div>
                </section>

                <div className="dl-modal__divider" />

                {/* Filter */}
                <section className="dl-modal__section">
                    <div className="dl-modal__filter-row">
                        <h3 className="dl-modal__label">{t.filterTitle}</h3>
                        <label className="dl-modal__checkbox">
                            <input type="checkbox" checked={useFiltered} onChange={() => setUseFiltered(!useFiltered)} />
                            <span className="dl-modal__checkbox-box" />
                            <span>{t.filterUserVersion}</span>
                        </label>
                    </div>
                </section>

                <div className="dl-modal__divider" />

                {/* File type */}
                <section className="dl-modal__section">
                    <h3 className="dl-modal__label">{t.fileTypeTitle}</h3>
                    <div className="dl-modal__file-types">
                        {(['csv', 'xls', 'pdf'] as FileType[]).map((ft) => (
                            <label key={ft} className="dl-modal__radio dl-modal__radio--inline">
                                <input type="radio" name="dlFileType" checked={fileType === ft} onChange={() => setFileType(ft)} />
                                <span className="dl-modal__radio-dot" />
                                <span className="dl-modal__file-label">{ft.toUpperCase()}</span>
                            </label>
                        ))}
                    </div>
                </section>

                <div className="dl-modal__divider" />

                {/* Language */}
                <section className="dl-modal__section">
                    <h3 className="dl-modal__label">{t.languageTitle}</h3>
                    <div className="dl-modal__file-types">
                        <label className="dl-modal__radio dl-modal__radio--inline">
                            <input type="radio" name="dlLang" checked={dlLang === 'fi'} onChange={() => setDlLang('fi')} />
                            <span className="dl-modal__radio-dot" />
                            <span>Suomi</span>
                        </label>
                        <label className="dl-modal__radio dl-modal__radio--inline">
                            <input type="radio" name="dlLang" checked={dlLang === 'en'} onChange={() => setDlLang('en')} />
                            <span className="dl-modal__radio-dot" />
                            <span>Englanti</span>
                        </label>
                    </div>
                </section>

                <div className="dl-modal__divider" />

                {/* Actions */}
                <div className="dl-modal__actions">
                    <button className="dl-modal__btn dl-modal__btn--outlined" type="button" onClick={onClose}>{t.cancel}</button>
                    <button className="dl-modal__btn dl-modal__btn--primary" type="button" onClick={handleDownload}>{t.download}</button>
                </div>
            </div>
        </div>
    );
}
