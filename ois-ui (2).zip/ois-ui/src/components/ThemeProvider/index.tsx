import { createContext, useContext, useState, useEffect, useMemo } from 'react';
import type { ReactNode } from 'react';
import './ThemeProvider.css';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type Theme = 'light' | 'dark';

interface ThemeContextValue {
    theme: Theme;
    setTheme: (theme: Theme) => void;
    toggleTheme: () => void;
}

// ---------------------------------------------------------------------------
// Context
// ---------------------------------------------------------------------------

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

/**
 * Hook to access the current theme and setter.
 *
 * Usage:
 *   const { theme, setTheme, toggleTheme } = useTheme();
 */
export function useTheme(): ThemeContextValue {
    const context = useContext(ThemeContext);
    if (!context) {
        throw new Error('useTheme must be used within a <ThemeProvider>');
    }
    return context;
}

// ---------------------------------------------------------------------------
// CSS Variable Tokens
// ---------------------------------------------------------------------------

/**
 * Design tokens — single source of truth.
 *
 * These map 1:1 with the CSS custom properties in ThemeProvider.css.
 * When efi-css is available, these will be overridden by the library's
 * variables.css / theme-light.css / theme-dark.css.
 *
 * Color reference:
 *   Primary (from Figma): #00B9A4
 *   Dark variant:         #009986
 *   Light variant:        #33C9B6
 */
const tokens = {
    light: {
        // Brand
        '--ois-color-primary': '#00B9A4',
        '--ois-color-primary-dark': '#009986',
        '--ois-color-primary-light': '#33C9B6',
        '--ois-color-primary-hover': '#00A896',

        // Backgrounds
        '--ois-color-bg': '#F5F5F5',
        '--ois-color-surface': '#FFFFFF',
        '--ois-color-surface-secondary': '#FAFAFA',

        // Borders
        '--ois-color-border': '#E0E0E0',
        '--ois-color-border-light': '#F0F0F0',

        // Text
        '--ois-color-text-primary': '#1A1A1A',
        '--ois-color-text-secondary': '#555555',
        '--ois-color-text-muted': '#999999',
        '--ois-color-text-inverse': '#FFFFFF',

        // Status
        '--ois-color-success': '#00B9A4',
        '--ois-color-error': '#D32F2F',
        '--ois-color-warning': '#F9A825',
        '--ois-color-info': '#1976D2',

        // Accent (for info boxes — the pink/magenta from Figma)
        '--ois-color-accent-info': '#D81B7A',

        // Shadows
        '--ois-shadow-sm': '0 1px 3px rgba(0, 0, 0, 0.06)',
        '--ois-shadow-md': '0 2px 8px rgba(0, 0, 0, 0.08)',
        '--ois-shadow-lg': '0 8px 32px rgba(0, 0, 0, 0.12)',
        '--ois-shadow-xl': '0 12px 40px rgba(0, 0, 0, 0.15)',

        // Overlay
        '--ois-overlay-bg': 'rgba(0, 0, 0, 0.45)',
    },
    dark: {
        // Brand
        '--ois-color-primary': '#00D4BC',
        '--ois-color-primary-dark': '#00B9A4',
        '--ois-color-primary-light': '#4DE0D0',
        '--ois-color-primary-hover': '#00C7B0',

        // Backgrounds
        '--ois-color-bg': '#121212',
        '--ois-color-surface': '#1E1E1E',
        '--ois-color-surface-secondary': '#2A2A2A',

        // Borders
        '--ois-color-border': '#333333',
        '--ois-color-border-light': '#2A2A2A',

        // Text
        '--ois-color-text-primary': '#E0E0E0',
        '--ois-color-text-secondary': '#AAAAAA',
        '--ois-color-text-muted': '#777777',
        '--ois-color-text-inverse': '#1A1A1A',

        // Status
        '--ois-color-success': '#00D4BC',
        '--ois-color-error': '#EF5350',
        '--ois-color-warning': '#FFB74D',
        '--ois-color-info': '#42A5F5',

        // Accent
        '--ois-color-accent-info': '#E91E8C',

        // Shadows
        '--ois-shadow-sm': '0 1px 3px rgba(0, 0, 0, 0.2)',
        '--ois-shadow-md': '0 2px 8px rgba(0, 0, 0, 0.3)',
        '--ois-shadow-lg': '0 8px 32px rgba(0, 0, 0, 0.4)',
        '--ois-shadow-xl': '0 12px 40px rgba(0, 0, 0, 0.5)',

        // Overlay
        '--ois-overlay-bg': 'rgba(0, 0, 0, 0.65)',
    },
} as const;

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

interface ThemeProviderProps {
    /** Initial theme — matches efi ThemeProvider API: <ThemeProvider theme="light"> */
    theme?: Theme;
    children: ReactNode;
}

/**
 * ThemeProvider — wraps the application and provides theme context + CSS variables.
 *
 * Usage (matches efi library API):
 *   <ThemeProvider theme="light">
 *       <App />
 *   </ThemeProvider>
 *
 * When efi library is available, replace this import:
 *   - FROM: import { ThemeProvider } from '@/components/ThemeProvider';
 *   - TO:   import { ThemeProvider } from '@efi/efi-ui-components';
 */
export function ThemeProvider({ theme: initialTheme = 'light', children }: ThemeProviderProps) {
    const [theme, setTheme] = useState<Theme>(initialTheme);

    // Apply CSS variables to :root whenever theme changes
    useEffect(() => {
        const root = document.documentElement;
        const themeTokens = tokens[theme];

        Object.entries(themeTokens).forEach(([key, value]) => {
            root.style.setProperty(key, value);
        });

        // Also set the legacy variable names for backward compat with existing CSS
        root.style.setProperty('--color-primary', themeTokens['--ois-color-primary']);
        root.style.setProperty('--color-primary-dark', themeTokens['--ois-color-primary-dark']);
        root.style.setProperty('--color-primary-light', themeTokens['--ois-color-primary-light']);
        root.style.setProperty('--color-primary-hover', themeTokens['--ois-color-primary-hover']);
        root.style.setProperty('--color-bg', themeTokens['--ois-color-bg']);
        root.style.setProperty('--color-surface', themeTokens['--ois-color-surface']);
        root.style.setProperty('--color-border', themeTokens['--ois-color-border']);
        root.style.setProperty('--color-text-primary', themeTokens['--ois-color-text-primary']);
        root.style.setProperty('--color-text-secondary', themeTokens['--ois-color-text-secondary']);
        root.style.setProperty('--color-text-muted', themeTokens['--ois-color-text-muted']);

        // Add data attribute for CSS-only theme selectors
        root.setAttribute('data-theme', theme);
    }, [theme]);

    const toggleTheme = () => {
        setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
    };

    const value = useMemo(() => ({ theme, setTheme, toggleTheme }), [theme]);

    return (
        <ThemeContext.Provider value={value}>
            <div className={`ois-theme ois-theme--${theme}`}>
                {children}
            </div>
        </ThemeContext.Provider>
    );
}
