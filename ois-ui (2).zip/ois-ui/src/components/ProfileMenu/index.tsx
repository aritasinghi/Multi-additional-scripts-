import { useState, useRef, useEffect } from 'react';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './ProfileMenu.css';

interface ProfileMenuProps {
    userName: string;
    company: string;
    department: string;
    language: Language;
    onLanguageChange: (lang: Language) => void;
    onNavigate?: (path: string) => void;
    onLogout?: () => void;
}

export function ProfileMenu({
    userName,
    company,
    department,
    language,
    onLanguageChange,
    onNavigate,
    onLogout,
}: ProfileMenuProps) {
    const [isOpen, setIsOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    // Close on outside click
    useEffect(() => {
        const handler = (e: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handler);
        return () => document.removeEventListener('mousedown', handler);
    }, []);

    // Close on Escape
    useEffect(() => {
        const handler = (e: KeyboardEvent) => {
            if (e.key === 'Escape') setIsOpen(false);
        };
        document.addEventListener('keydown', handler);
        return () => document.removeEventListener('keydown', handler);
    }, []);

    const languages: { key: Language; label: string }[] = [
        { key: 'en', label: 'English' },
        { key: 'sv', label: 'Svenska' },
        { key: 'fi', label: 'Suomi' },
    ];

    const t = translations[language].profileMenu;

    const menuItems = [
        { value: 'dashboard', label: t.dashboard, disabled: false },
        { value: 'profile', label: t.profile, disabled: false },
        { value: 'disabled', label: t.notAvailable, disabled: true },
        { value: 'logout', label: t.logout, disabled: false },
    ];

    return (
        <div className="profile-menu" ref={menuRef}>
            <button
                className="profile-menu__trigger"
                type="button"
                aria-label={t.yourProfile}
                aria-expanded={isOpen}
                onClick={() => setIsOpen(!isOpen)}
            >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="8" r="4" stroke="currentColor" strokeWidth="1.5" />
                    <path
                        d="M4 21c0-4 3.5-6.5 8-6.5s8 2.5 8 6.5"
                        stroke="currentColor"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                    />
                </svg>
            </button>

            {isOpen && (
                <div className="profile-menu__dropdown">
                    {/* User icon */}
                    <div className="profile-menu__avatar">
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                            <circle cx="16" cy="11" r="5" stroke="currentColor" strokeWidth="1.5" />
                            <path
                                d="M5 28c0-5 4.5-8.5 11-8.5s11 3.5 11 8.5"
                                stroke="currentColor"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                            />
                        </svg>
                    </div>

                    {/* User info */}
                    <h3 className="profile-menu__name">{userName}</h3>

                    <div className="profile-menu__info">
                        <span className="profile-menu__info-label">{t.companyLabel}</span>
                        <span className="profile-menu__info-value">{company}</span>
                    </div>

                    <div className="profile-menu__info">
                        <span className="profile-menu__info-label">{t.departmentLabel}</span>
                        <span className="profile-menu__info-value">{department}</span>
                    </div>

                    {/* Language switcher — pill toggle */}
                    <div className="profile-menu__lang-switcher">
                        {languages.map(({ key, label }) => (
                            <button
                                key={key}
                                className={`profile-menu__lang-btn ${language === key ? 'profile-menu__lang-btn--active' : ''}`}
                                type="button"
                                onClick={() => onLanguageChange(key)}
                            >
                                {label}
                            </button>
                        ))}
                    </div>

                    {/* Menu items */}
                    <div className="profile-menu__items">
                        {menuItems.map(({ value, label, disabled }) => (
                            <button
                                key={value}
                                className={`profile-menu__item ${disabled ? 'profile-menu__item--disabled' : ''}`}
                                type="button"
                                disabled={disabled}
                                onClick={() => {
                                    if (value === 'logout') {
                                        onLogout?.();
                                    } else {
                                        onNavigate?.(value);
                                    }
                                    setIsOpen(false);
                                }}
                            >
                                {label}
                            </button>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}
