import { useState } from 'react';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import { DatePicker } from '@/components/DatePicker';
import './SubscriptionModal.css';

type OrderType = 'one-time' | 'recurring';
type DateMode = 'latest' | 'end-of-day' | 'custom';
type Frequency = 'daily' | 'monthly' | 'monthly-last' | 'quarterly' | 'quarterly-last' | 'yearly';

interface ValueShare { id: string; label: string; isin: string; checked: boolean; }

interface SubscriptionModalProps {
    isOpen: boolean;
    reportTitle: string;
    onClose: () => void;
    onSubmit: (data: SubscriptionFormData) => void;
    language?: Language;
}

export interface SubscriptionFormData {
    orderType: OrderType;
    dateMode: DateMode;
    selectedDate?: Date;
    frequency: Frequency;
    dayOfMonth: number;
    selectedShares: string[];
    reference: string;
}

const INITIAL_SHARES: ValueShare[] = [
    { id: '1', label: 'Euroflex A', isin: 'FI21049685930', checked: true },
    { id: '2', label: 'Euroflex B', isin: 'FI21049685931', checked: true },
    { id: '3', label: 'Euroflex B', isin: 'FI21049685931', checked: true },
    { id: '4', label: 'Euroflex A', isin: 'FI21049685930', checked: true },
    { id: '5', label: 'Euroflex B', isin: 'FI21049685931', checked: true },
    { id: '6', label: 'Euroflex B', isin: 'FI21049685931', checked: true },
];

export function SubscriptionModal({ isOpen, reportTitle, onClose, onSubmit, language = 'fi' }: SubscriptionModalProps) {
    const t = translations[language].subscription;
    const [orderType, setOrderType] = useState<OrderType>('one-time');
    const [dateMode, setDateMode] = useState<DateMode>('custom');
    const [selectedDate, setSelectedDate] = useState<Date | null>(new Date(2024, 1, 22));
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [frequency, setFrequency] = useState<Frequency>('monthly');
    const [dayOfMonth, setDayOfMonth] = useState(31);
    const [shares, setShares] = useState<ValueShare[]>(INITIAL_SHARES);
    const [reference, setReference] = useState('');

    if (!isOpen) return null;

    const toggleShare = (id: string) => setShares((p) => p.map((s) => s.id === id ? { ...s, checked: !s.checked } : s));
    const dateLocale = language === 'fi' ? 'fi-FI' : language === 'sv' ? 'sv-SE' : 'en-GB';

    const handleSubmit = () => {
        onSubmit({ orderType, dateMode, selectedDate: selectedDate ?? undefined, frequency, dayOfMonth, selectedShares: shares.filter((s) => s.checked).map((s) => s.id), reference });
    };

    const frequencies: { key: Frequency; label: string }[] = [
        { key: 'daily', label: t.daily },
        { key: 'monthly', label: t.monthly },
        { key: 'monthly-last', label: t.monthlyLast },
        { key: 'quarterly', label: t.quarterly },
        { key: 'quarterly-last', label: t.quarterlyLast },
        { key: 'yearly', label: t.yearly },
    ];

    const getFrequencyInfo = () => {
        if (frequency.startsWith('monthly')) return t.frequencyInfoMonthly;
        if (frequency.startsWith('quarterly')) return t.frequencyInfoQuarterly;
        if (frequency === 'yearly') return t.frequencyInfoYearly;
        return t.frequencyInfoMonthly;
    };

    return (
        <div className="sub-modal__overlay" onClick={onClose}>
            <div className="sub-modal" onClick={(e) => e.stopPropagation()}>

                {/* ── Header ── */}
                <div className="sub-modal__header">
                    <h2 className="sub-modal__title">{t.title}: {reportTitle}</h2>
                    <div className="sub-modal__order-toggle">
                        <label className="sub-modal__radio-pill">
                            <input type="radio" name="orderType" checked={orderType === 'one-time'} onChange={() => setOrderType('one-time')} />
                            <span>{t.oneTime}</span>
                        </label>
                        <label className="sub-modal__radio-pill">
                            <input type="radio" name="orderType" checked={orderType === 'recurring'} onChange={() => setOrderType('recurring')} />
                            <span>{t.recurring}</span>
                        </label>
                    </div>
                </div>

                <div className="sub-modal__divider" />

                {/* ══════════════════════════════════════════════════════════
                   ONE-TIME ORDER — "Kertatilaus"
                   ══════════════════════════════════════════════════════════ */}
                {orderType === 'one-time' && (
                    <section className="sub-modal__section">
                        <h3 className="sub-modal__section-title">{t.oneTimeTitle}</h3>

                        <div className="sub-modal__two-col">
                            <div className="sub-modal__col-left">
                                <h4 className="sub-modal__label">{t.reportDateTitle}</h4>

                                <div className="sub-modal__date-modes">
                                    {/* Left column radios */}
                                    <div className="sub-modal__date-modes-col">
                                        <label className="sub-modal__radio">
                                            <input type="radio" name="dateMode" checked={dateMode === 'latest'} onChange={() => setDateMode('latest')} />
                                            <span className="sub-modal__radio-dot" />
                                            <span className="sub-modal__radio-text">{t.dateLatest}</span>
                                        </label>
                                        <label className="sub-modal__radio">
                                            <input type="radio" name="dateMode" checked={dateMode === 'end-of-day'} onChange={() => setDateMode('end-of-day')} />
                                            <span className="sub-modal__radio-dot" />
                                            <span className="sub-modal__radio-text">{t.dateEndOfDay}</span>
                                        </label>
                                    </div>

                                    {/* Right column: custom date */}
                                    <div className="sub-modal__date-modes-col">
                                        <label className="sub-modal__radio">
                                            <input type="radio" name="dateMode" checked={dateMode === 'custom'} onChange={() => setDateMode('custom')} />
                                            <span className="sub-modal__radio-dot" />
                                            <span className="sub-modal__radio-text">{t.dateSelectCustom}</span>
                                        </label>
                                        {dateMode === 'custom' && (
                                            <div className="sub-modal__date-input-wrap">
                                                <label className="sub-modal__date-input-label">{t.selectDateLabel}</label>
                                                <button type="button" className="sub-modal__date-trigger" onClick={() => setShowDatePicker(true)}>
                                                    {selectedDate ? selectedDate.toLocaleDateString(dateLocale) : t.selectDateLabel}
                                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                        <rect x="2" y="3" width="12" height="11" rx="1.5" stroke="currentColor" strokeWidth="1.2" />
                                                        <path d="M2 6.5h12" stroke="currentColor" strokeWidth="1.2" />
                                                        <path d="M5 1.5v3M11 1.5v3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
                                                    </svg>
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>

                            {/* Right info box — WHITE/GREY (not pink) */}
                            <div className="sub-modal__info-box sub-modal__info-box--light">
                                <h4 className="sub-modal__info-title">{t.dateInfoTitle}</h4>
                                <p className="sub-modal__info-text">{t.dateInfoDesc}</p>
                            </div>
                        </div>
                    </section>
                )}

                {/* ══════════════════════════════════════════════════════════
                   RECURRING ORDER — "Toistuva tilaus"
                   ══════════════════════════════════════════════════════════ */}
                {orderType === 'recurring' && (
                    <section className="sub-modal__section">
                        <h3 className="sub-modal__section-title">{t.recurringTitle}</h3>

                        <div className="sub-modal__two-col">
                            <div className="sub-modal__col-left">
                                <h4 className="sub-modal__label">{t.frequencyTitle}</h4>
                                <div className="sub-modal__freq-grid">
                                    {frequencies.map(({ key, label }) => (
                                        <label key={key} className="sub-modal__radio">
                                            <input type="radio" name="frequency" value={key} checked={frequency === key} onChange={() => setFrequency(key)} />
                                            <span className="sub-modal__radio-dot" />
                                            <span className="sub-modal__radio-text">{label}</span>
                                        </label>
                                    ))}
                                </div>
                                {(frequency === 'monthly' || frequency === 'quarterly' || frequency === 'yearly') && (
                                    <div className="sub-modal__day-select">
                                        <label className="sub-modal__label">{t.selectDay}</label>
                                        <input type="number" className="sub-modal__number-input" min={1} max={31} value={dayOfMonth} onChange={(e) => setDayOfMonth(Number(e.target.value))} />
                                    </div>
                                )}
                            </div>

                            {/* Right: WHITE info box on top + PINK note below */}
                            <div className="sub-modal__info-stack">
                                <div className="sub-modal__info-box sub-modal__info-box--light">
                                    <h4 className="sub-modal__info-title">{t.frequencyInfoTitle}</h4>
                                    <p className="sub-modal__info-text">{getFrequencyInfo()}</p>
                                </div>
                                <div className="sub-modal__info-box sub-modal__info-box--pink">
                                    <p className="sub-modal__info-text">{t.frequencyInfoMonthlyNote}</p>
                                </div>
                            </div>
                        </div>
                    </section>
                )}

                <div className="sub-modal__divider" />

                {/* ── Shares ── */}
                <section className="sub-modal__section">
                    <div className="sub-modal__two-col">
                        <div className="sub-modal__col-left">
                            <h3 className="sub-modal__section-title">{t.sharesTitle}</h3>
                            <p className="sub-modal__shares-type">{t.shareType}</p>
                            <div className="sub-modal__shares-grid">
                                {shares.map((share) => (
                                    <label key={share.id} className="sub-modal__checkbox">
                                        <input type="checkbox" checked={share.checked} onChange={() => toggleShare(share.id)} />
                                        <span className="sub-modal__checkbox-box" />
                                        <span className="sub-modal__checkbox-label">
                                            <span className="sub-modal__checkbox-name">{share.label}</span>
                                            <span className="sub-modal__checkbox-isin">{share.isin}</span>
                                        </span>
                                    </label>
                                ))}
                            </div>
                        </div>
                        <div className="sub-modal__info-box sub-modal__info-box--light">
                            <h4 className="sub-modal__info-title">{t.shareSelectionTitle}</h4>
                            <p className="sub-modal__info-text">{t.shareSelectionDesc}</p>
                        </div>
                    </div>
                </section>

                <div className="sub-modal__divider" />

                {/* ── Reference ── */}
                <section className="sub-modal__section">
                    <div className="sub-modal__two-col">
                        <div className="sub-modal__col-left">
                            <label className="sub-modal__label">{t.referenceLabel}</label>
                            <input type="text" className="sub-modal__text-input" placeholder={t.referencePlaceholder} value={reference} onChange={(e) => setReference(e.target.value)} />
                        </div>
                        <div className="sub-modal__info-box sub-modal__info-box--light">
                            <h4 className="sub-modal__info-title">{t.referenceInfoTitle}</h4>
                            <p className="sub-modal__info-text">{t.referenceInfoDesc}</p>
                        </div>
                    </div>
                </section>

                <div className="sub-modal__divider" />

                {/* ── Price + Actions ── */}
                <div className="sub-modal__footer">
                    <div className="sub-modal__price-row">
                        <p className="sub-modal__price-note">{t.priceNote}</p>
                        <p className="sub-modal__price-next">{t.priceNextView}</p>
                    </div>
                    <div className="sub-modal__actions">
                        <button className="sub-modal__btn sub-modal__btn--outlined" type="button" onClick={onClose}>{t.cancel}</button>
                        <button className="sub-modal__btn sub-modal__btn--primary" type="button" onClick={handleSubmit}>{t.submit}</button>
                    </div>
                </div>
            </div>

            <DatePicker isOpen={showDatePicker} lang={language} selectedDate={selectedDate ?? undefined}
                onSelect={(d) => { setSelectedDate(d); setShowDatePicker(false); }}
                onCancel={() => setShowDatePicker(false)} />
        </div>
    );
}
