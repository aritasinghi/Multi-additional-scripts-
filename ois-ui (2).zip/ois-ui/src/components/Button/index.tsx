import type { ReactNode, ButtonHTMLAttributes } from 'react';
import './Button.css';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    variant?: 'primary' | 'outlined';
    fullWidth?: boolean;
    children: ReactNode;
}

export function Button({
    variant = 'primary',
    fullWidth = false,
    children,
    className = '',
    ...props
}: ButtonProps) {
    return (
        <button
            className={`ois-btn ois-btn--${variant} ${fullWidth ? 'ois-btn--full' : ''} ${className}`.trim()}
            {...props}
        >
            {children}
        </button>
    );
}
