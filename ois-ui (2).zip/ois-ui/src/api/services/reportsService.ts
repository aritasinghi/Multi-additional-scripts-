import { api } from '@/api/client';
import type { SubscribedReport, AvailableReport, SubscriptionFormValues } from '@/types';

/**
 * Reports API service — each function maps to a single REST endpoint.
 * Used by TanStack Query hooks, never called directly from components.
 */
export const reportsService = {
    getSubscribed: () => api.get<SubscribedReport[]>('/reports/subscribed'),
    getAvailable: () => api.get<AvailableReport[]>('/reports/available'),
    getById: (id: string) => api.get<SubscribedReport>(`/reports/${id}`),
    subscribe: (values: SubscriptionFormValues) =>
        api.post<{ id: string }>('/subscriptions', values),
    unsubscribe: (id: string) => api.delete<void>(`/subscriptions/${id}`),
};
