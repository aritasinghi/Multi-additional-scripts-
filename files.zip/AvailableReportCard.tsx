import React from 'react';
import Button from '../Button/Button';
import './AvailableReportCard.css';

interface AvailableReportCardProps {
  title: string;
  subtitle?: string;
  onPreview?: () => void;
  onOrder?: () => void;
}

const AvailableReportCard: React.FC<AvailableReportCardProps> = ({
  title,
  subtitle = 'Tilaa uusi raportti valikoimasta.',
  onPreview,
  onOrder,
}) => {
  return (
    <div className="available-card">
      <div className="available-card__content">
        <div className="available-card__plus">+</div>
        <h3 className="available-card__title">{title}</h3>
        {subtitle && (
          <p className="available-card__subtitle">{subtitle}</p>
        )}
      </div>

      <div className="available-card__actions">
        <Button variant="outline" fullWidth onClick={onPreview}>
          NÄYTÄ ESIKATSELU
        </Button>
        <Button variant="primary" fullWidth onClick={onOrder}>
          TILAA RAPORTTI
        </Button>
      </div>
    </div>
  );
};

export default AvailableReportCard;
