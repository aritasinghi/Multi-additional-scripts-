export { default } from './ReportCard';
export { default as ReportCard } from './ReportCard';
