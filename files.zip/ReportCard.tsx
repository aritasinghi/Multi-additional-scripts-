import React from 'react';
import Button from '../Button/Button';
import './ReportCard.css';

interface DataRow {
  name: string;
  value: string;
}

interface ReportCardProps {
  title: string;
  badge?: string;
  dataRows?: DataRow[];
  lastReportDate?: string;
  allReportsCount?: number;
  avatars?: Array<{ initials: string; color?: string }>;
  onOrderNew?: () => void;
  onViewAll?: () => void;
  onLastReport?: () => void;
}

const ReportCard: React.FC<ReportCardProps> = ({
  title,
  badge,
  dataRows = [],
  lastReportDate,
  allReportsCount,
  avatars = [],
  onOrderNew,
  onViewAll,
  onLastReport,
}) => {
  return (
    <div className="report-card">
      {/* Header */}
      <div className="report-card__header">
        <h3 className="report-card__title">{title}</h3>
        {badge && <span className="report-card__badge">{badge}</span>}
      </div>

      {/* Data Table */}
      {dataRows.length > 0 && (
        <table className="report-card__data-table">
          <thead>
            <tr className="report-card__data-header">
              <th></th>
              <th>%</th>
            </tr>
          </thead>
          <tbody>
            {dataRows.map((row, i) => (
              <tr key={i}>
                <td>{row.name}</td>
                <td>{row.value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* Footer */}
      <div className="report-card__footer">
        {/* Avatars + Last Report Date */}
        <div className="report-card__meta">
          {avatars.length > 0 && (
            <div className="report-card__avatars">
              {avatars.map((av, i) => (
                <span
                  key={i}
                  className="report-card__avatar"
                  style={{ backgroundColor: av.color || '#00B9A4' }}
                >
                  {av.initials}
                </span>
              ))}
            </div>
          )}
          {lastReportDate && (
            <span className="report-card__date-link" onClick={onLastReport}>
              Näytä viimeisin raportti: {lastReportDate}
            </span>
          )}
        </div>

        <div className="report-card__divider" />

        {/* View All Reports */}
        {allReportsCount !== undefined && (
          <button className="report-card__view-link" onClick={onViewAll}>
            NÄYTÄ KAIKKI TILATUT RAPORTIT ({allReportsCount})
          </button>
        )}

        {/* Actions */}
        <div className="report-card__actions">
          <Button variant="primary" fullWidth onClick={onOrderNew}>
            + TILAA UUSI RAPORTTI
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ReportCard;
