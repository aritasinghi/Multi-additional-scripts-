import React from 'react';
import styles from './Card.module.css';

interface CardProps {
  children: React.ReactNode;
  textAlign?: 'left' | 'center' | 'right';
  className?: string;
}

export const Card = ({
  children,
  textAlign = 'left',
  className = '',
}: CardProps) => {
  return (
    <div className={`${styles.card} ${className}`} style={{ textAlign }}>
      {children}
    </div>
  );
};

export default Card;
