import React from 'react';
import { Main, Container } from '@efi/efi-ui-components';
import ReportCard from '../components/ReportCard';
import AvailableReportCard from '../components/AvailableReportCard';
import './ReportsPage.css';

const subscribedReports = [
  {
    id: 1,
    title: 'Liikkeeseenlaskijan osakasluettelo',
    badge: 'UUSI',
    dataRows: [
      { name: 'Tulip Bank', value: '10,00' },
      { name: 'Flexis Bank', value: '9,00' },
      { name: 'S. Sunflower', value: '8,00' },
      { name: 'C. Coriander', value: '7,00' },
      { name: 'H. Hazel', value: '6,00' },
      { name: 'T. Tulip', value: '5,00' },
    ],
    lastReportDate: '24.01.2026',
    allReportsCount: 3,
    avatars: [
      { initials: 'E', color: '#2196F3' },
      { initials: 'J', color: '#4CAF50' },
    ],
  },
  {
    id: 2,
    title: 'Julkinen osakasluettelo',
    badge: undefined,
    dataRows: [
      { name: 'Tulip Bank', value: '10,00' },
      { name: 'Flexis Bank', value: '9,00' },
      { name: 'S. Sunflower', value: '8,00' },
      { name: 'C. Coriander', value: '7,00' },
      { name: 'H. Hazel', value: '6,00' },
      { name: 'T. Tulip', value: '5,00' },
    ],
    lastReportDate: '01.01.2026',
    allReportsCount: 2,
    avatars: [
      { initials: 'J', color: '#4CAF50' },
    ],
  },
  {
    id: 3,
    title: 'Kattava omistajapoiminta',
    badge: undefined,
    dataRows: [
      { name: 'Tulip Bank', value: '10,00' },
      { name: 'Flexis Bank', value: '9,00' },
      { name: 'S. Sunflower', value: '8,00' },
      { name: 'C. Coriander', value: '7,00' },
      { name: 'H. Hazel', value: '6,00' },
      { name: 'T. Tulip', value: '5,00' },
    ],
    lastReportDate: '24.11.2025',
    allReportsCount: 4,
    avatars: [],
  },
];

const availableReports = [
  { id: 1, title: 'Suurimmat omistajat' },
  { id: 2, title: 'Sektorijakauma' },
  { id: 3, title: 'Omistusmääräjakauma' },
  { id: 4, title: 'Omistajapoiminta' },
];

export default function ReportsPage() {
  return (
    <Main>
      <Container>
        {/* Page Title */}
        <div className="reports-page__title">
          <h2>Raportit</h2>
        </div>

        {/* Subscribed Reports */}
        <section className="reports-page__section">
          <h4 className="reports-page__section-title">Tilatut raporttityypit</h4>
          <div className="reports-page__grid">
            {subscribedReports.map((report) => (
              <ReportCard
                key={report.id}
                title={report.title}
                badge={report.badge}
                dataRows={report.dataRows}
                lastReportDate={report.lastReportDate}
                allReportsCount={report.allReportsCount}
                avatars={report.avatars}
                onOrderNew={() => console.log('Order new', report.title)}
                onViewAll={() => console.log('View all', report.title)}
                onLastReport={() => console.log('Last report', report.title)}
              />
            ))}
          </div>
        </section>

        {/* Available Reports */}
        <section className="reports-page__section">
          <h4 className="reports-page__section-title">
            Muut saatavilla olevat raporttityypit
          </h4>
          <div className="reports-page__grid">
            {availableReports.map((report) => (
              <AvailableReportCard
                key={report.id}
                title={report.title}
                onPreview={() => console.log('Preview', report.title)}
                onOrder={() => console.log('Order', report.title)}
              />
            ))}
          </div>
        </section>
      </Container>
    </Main>
  );
}
